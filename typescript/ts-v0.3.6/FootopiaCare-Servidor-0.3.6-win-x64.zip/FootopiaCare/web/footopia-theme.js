(function () {
    'use strict';
    if (window.footopiaTheme) { window.footopiaTheme.refresh(); return; }

    const key = 'footopia.theme';
    const root = document.documentElement;
    const normalize = value => value === 'dark' ? 'dark' : 'light';
    let preference = 'light';
    try { preference = normalize(localStorage.getItem(key)); } catch { /* Conservar durante esta visita. */ }

    function syncControls() {
        const label = preference === 'dark' ? 'Activar tema claro' : 'Activar tema oscuro';
        document.querySelectorAll('[data-fc-theme-picker]').forEach(button => {
            button.setAttribute('aria-pressed', String(preference === 'dark'));
            button.setAttribute('aria-label', label);
            button.setAttribute('title', label);
        });
    }

    function apply() {
        const dark = preference === 'dark';
        root.dataset.fcTheme = preference;
        root.dataset.fcThemePreference = preference;
        const meta = document.querySelector('meta[name="theme-color"]');
        if (meta) meta.content = dark ? '#10191e' : '#0A6B88';
        syncControls();
    }

    // Antes del primer pintado; la preferencia antigua «Sistema» pasa a claro.
    apply();
    document.addEventListener('DOMContentLoaded', () => {
        syncControls();
        new MutationObserver(records => {
            if (records.some(record => [...record.addedNodes].some(node => node instanceof Element &&
                (node.matches('[data-fc-theme-picker]') || node.querySelector('[data-fc-theme-picker]'))))) syncControls();
        }).observe(document.body, { childList: true, subtree: true });
    });
    window.addEventListener('storage', event => {
        if (event.key !== key && event.key !== null) return;
        preference = normalize(event.newValue);
        apply();
    });
    document.addEventListener('click', event => {
        if (!(event.target instanceof Element) || !event.target.closest('[data-fc-theme-picker]')) return;
        preference = preference === 'dark' ? 'light' : 'dark';
        try { localStorage.setItem(key, preference); } catch { /* Funciona sin persistencia. */ }
        apply();
    });
    window.footopiaTheme = { refresh: apply };
})();
