// Menú común para todos los selectores. El select conserva su valor, etiqueta,
// foco y eventos de formulario de Blazor; sólo sustituimos el menú del sistema.
(() => {
    let opened = null;
    let sequence = 0;
    const selector = 'select.fc-select:not([multiple])';
    const isSelect = target => target instanceof HTMLSelectElement &&
        target.matches(selector) && target.size <= 1 && !target.matches(':disabled');
    const normalize = text => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es');

    function close() {
        if (!opened) return;
        const state = opened;
        opened = null;
        state.observer.disconnect();
        state.panel.remove();
        for (const [name, value] of state.attributes) {
            if (value === null) state.select.removeAttribute(name);
            else state.select.setAttribute(name, value);
        }
    }

    function position() {
        if (!opened) return;
        const { select, panel } = opened;
        if (!select.isConnected || select.matches(':disabled') || !select.getClientRects().length) {
            close();
            return;
        }
        const viewport = window.visualViewport;
        const leftEdge = (viewport?.offsetLeft || 0) + 8;
        const topEdge = (viewport?.offsetTop || 0) + 8;
        const rightEdge = leftEdge + (viewport?.width || window.innerWidth) - 16;
        const bottomEdge = topEdge + (viewport?.height || window.innerHeight) - 16;
        const rect = select.getBoundingClientRect();
        if (rect.bottom < topEdge || rect.top > bottomEdge || rect.right < leftEdge || rect.left > rightEdge) {
            close();
            return;
        }
        const below = bottomEdge - rect.bottom - 6;
        const above = rect.top - topEdge - 6;
        const upwards = below < Math.min(240, panel.scrollHeight) && above > below;
        panel.style.width = Math.min(rect.width, rightEdge - leftEdge) + 'px';
        panel.style.maxHeight = Math.max(48, Math.min(320, upwards ? above : below)) + 'px';
        panel.style.left = Math.max(leftEdge, Math.min(rect.left, rightEdge - panel.offsetWidth)) + 'px';
        panel.style.top = Math.max(topEdge, upwards ? rect.top - panel.offsetHeight - 6 : rect.bottom + 6) + 'px';
    }

    function activate(index) {
        if (!opened) return;
        const { select, panel } = opened;
        const options = [...panel.querySelectorAll('[role="option"]')];
        const active = options.find(option => Number(option.dataset.index) === index);
        if (!active || active.getAttribute('aria-disabled') === 'true') return;
        opened.active = index;
        for (const option of options) option.classList.toggle('is-active', option === active);
        select.setAttribute('aria-activedescendant', active.id);
        // Desplaza sólo la lista: scrollIntoView también movería el modal/página.
        if (active.offsetTop < panel.scrollTop) panel.scrollTop = active.offsetTop;
        else if (active.offsetTop + active.offsetHeight > panel.scrollTop + panel.clientHeight)
            panel.scrollTop = active.offsetTop + active.offsetHeight - panel.clientHeight;
    }

    function enabledIndices() {
        return [...opened.panel.querySelectorAll('[role="option"]:not([aria-disabled="true"])')]
            .map(option => Number(option.dataset.index));
    }

    function render() {
        const { select, panel } = opened;
        const content = document.createDocumentFragment();
        let previousGroup = null;
        [...select.options].forEach((option, index) => {
            const group = option.parentElement instanceof HTMLOptGroupElement ? option.parentElement : null;
            if (option.hidden || group?.hidden) return;
            if (group && group !== previousGroup) {
                const heading = document.createElement('div');
                heading.className = 'fc-select-group';
                heading.setAttribute('role', 'presentation');
                heading.textContent = group.label;
                content.append(heading);
            }
            previousGroup = group;
            const item = document.createElement('div');
            item.id = panel.id + '-option-' + index;
            item.className = 'fc-select-option';
            item.dataset.index = String(index);
            item.setAttribute('role', 'option');
            item.setAttribute('aria-selected', String(option.selected));
            if (option.disabled || group?.disabled) item.setAttribute('aria-disabled', 'true');
            const label = document.createElement('span');
            label.textContent = option.label;
            item.append(label);
            if (option.selected) {
                const check = document.createElement('span');
                check.className = 'material-symbols-outlined';
                check.setAttribute('aria-hidden', 'true');
                check.textContent = 'check';
                item.append(check);
            }
            content.append(item);
        });
        panel.replaceChildren(content);
        position();
        if (!opened) return;
        const enabled = enabledIndices();
        activate(enabled.includes(opened.active) ? opened.active :
            enabled.includes(select.selectedIndex) ? select.selectedIndex : enabled[0]);
    }

    function commit(index) {
        if (!opened) return;
        const { select } = opened;
        if (select.matches(':disabled')) { close(); return; }
        const option = select.options[index];
        if (!option || option.disabled || option.parentElement.disabled || option.hidden) return;
        const changed = select.selectedIndex !== index;
        close();
        select.selectedIndex = index;
        if (changed) {
            select.dispatchEvent(new Event('input', { bubbles: true }));
            select.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }

    function open(select) {
        close();
        const panel = document.createElement('div');
        panel.id = 'fc-select-list-' + ++sequence;
        panel.className = 'fc-select-menu';
        panel.setAttribute('role', 'listbox');
        const labelledBy = select.getAttribute('aria-labelledby');
        if (labelledBy) panel.setAttribute('aria-labelledby', labelledBy);
        else panel.setAttribute('aria-label', select.getAttribute('aria-label') ||
            [...select.labels].map(label => label.textContent.trim()).join(' ') || 'Opciones');
        const names = ['aria-expanded', 'aria-controls', 'aria-activedescendant'];
        const attributes = names.map(name => [name, select.getAttribute(name)]);
        const observer = new MutationObserver(records => {
            if (!select.isConnected || select.matches(':disabled') || !select.getClientRects().length) close();
            else if (records.some(record => record.target === select || select.contains(record.target))) render();
        });
        opened = { select, panel, attributes, observer, active: select.selectedIndex, search: '', searchedAt: 0 };
        select.focus({ preventScroll: true });
        select.setAttribute('aria-expanded', 'true');
        select.setAttribute('aria-controls', panel.id);
        // La capa superior evita que los formularios y modales recorten la lista.
        if (typeof panel.showPopover === 'function') panel.setAttribute('popover', 'manual');
        document.body.append(panel);
        if (panel.hasAttribute('popover')) panel.showPopover();
        render();
        if (!opened) return;
        observer.observe(document.body, { childList: true, subtree: true, attributes: true,
            attributeFilter: ['disabled', 'hidden', 'selected', 'value', 'label', 'class', 'style'] });
        panel.addEventListener('pointerdown', event => event.preventDefault());
        panel.addEventListener('click', event => {
            const item = event.target.closest('[role="option"]');
            if (item && item.getAttribute('aria-disabled') !== 'true') commit(Number(item.dataset.index));
        });
    }

    document.addEventListener('pointerdown', event => {
        if (isSelect(event.target) && event.button === 0) {
            event.preventDefault();
            if (opened?.select === event.target) close();
            else open(event.target);
        } else if (opened && !opened.panel.contains(event.target)) close();
    }, true);
    document.addEventListener('mousedown', event => {
        if (isSelect(event.target)) event.preventDefault();
    }, true);
    document.addEventListener('click', event => {
        if (!isSelect(event.target)) return;
        event.preventDefault();
        // Activaciones de etiqueta o tecnología asistiva no tienen pointerdown.
        if (event.detail === 0) {
            if (opened?.select === event.target) close();
            else open(event.target);
        }
    }, true);
    document.addEventListener('keydown', event => {
        if (!isSelect(event.target) || event.ctrlKey || event.metaKey) return;
        if (event.key === 'Tab') { close(); return; }
        if (event.key === 'Escape' || (event.altKey && event.key === 'ArrowUp')) {
            if (opened) { event.preventDefault(); event.stopImmediatePropagation(); close(); }
            return;
        }
        const navigation = ['ArrowDown', 'ArrowUp', 'Home', 'End', 'PageDown', 'PageUp'];
        const isText = event.key.length === 1 && !event.altKey;
        if (!navigation.includes(event.key) && !['Enter', ' '].includes(event.key) && !isText) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        if (!opened) { open(event.target); if (['Enter', ' '].includes(event.key)) return; }
        if (!opened) return;
        if (['Enter', ' '].includes(event.key)) { commit(opened.active); return; }
        const enabled = enabledIndices();
        if (!enabled.length) return;
        const current = Math.max(0, enabled.indexOf(opened.active));
        if (event.key === 'Home') activate(enabled[0]);
        else if (event.key === 'End') activate(enabled.at(-1));
        else if (navigation.includes(event.key)) {
            const step = event.key.startsWith('Page') ? 5 : 1;
            const direction = ['ArrowUp', 'PageUp'].includes(event.key) ? -1 : 1;
            activate(enabled[Math.max(0, Math.min(enabled.length - 1, current + step * direction))]);
        } else if (isText) {
            const now = Date.now();
            const character = normalize(event.key);
            opened.search = now - opened.searchedAt < 700 ? opened.search + character : character;
            opened.searchedAt = now;
            const repeated = [...opened.search].every(value => value === character);
            const query = repeated ? character : opened.search;
            const start = repeated ? current + 1 : current;
            const ordered = enabled.slice(start).concat(enabled.slice(0, start));
            const match = ordered.find(index => normalize(opened.select.options[index].label).startsWith(query));
            if (match !== undefined) activate(match);
        }
    }, true);
    document.addEventListener('focusin', event => {
        if (opened && event.target !== opened.select) close();
    });
    document.addEventListener('change', event => { if (opened?.select === event.target) close(); });
    document.addEventListener('enhancedload', close);
    window.addEventListener('blur', close);
    window.addEventListener('resize', position);
    window.addEventListener('scroll', event => {
        if (opened && !opened.panel.contains(event.target)) position();
    }, true);
    window.visualViewport?.addEventListener('resize', position);
    window.visualViewport?.addEventListener('scroll', position);
})();
