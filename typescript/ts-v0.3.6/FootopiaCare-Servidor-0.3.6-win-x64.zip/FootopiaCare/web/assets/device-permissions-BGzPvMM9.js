let e;function s(){return e}export{s as d};
