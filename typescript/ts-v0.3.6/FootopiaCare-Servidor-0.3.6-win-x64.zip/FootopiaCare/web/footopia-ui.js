window.footopiaCare = window.footopiaCare || {};

// El selector consulta sólo por acción explícita. Enter no debe enviar el
// formulario padre y las flechas recorren resultados sin desplazar la página.
document.addEventListener('keydown', event => {
    if (event.target instanceof HTMLInputElement && event.target.hasAttribute('data-fc-patient-search') &&
        !event.isComposing && ['Enter', 'ArrowDown', 'ArrowUp'].includes(event.key)) event.preventDefault();
}, true);

window.footopiaCare.scrollPatientOption = function (id) {
    const option = document.getElementById(id);
    if (option?.getAttribute('role') === 'option') option.scrollIntoView({ block: 'nearest', inline: 'nearest' });
};

window.footopiaCare.downloadText = function (fileName, content, contentType) {
    const blob = new Blob([content], { type: contentType || 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
};

// Mostrar/ocultar contraseña (Fase 2): solo alterna la presentación del campo,
// nunca su valor. Delegado en document para que funcione en páginas SSR (Login,
// Setup) y en modales renderizados después (Usuarios). Mantiene foco y cursor.
window.footopiaCare.togglePassword = function (inputId, button) {
    const input = document.getElementById(inputId);
    if (!(input instanceof HTMLInputElement)) return;
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    const label = show ? 'Ocultar contraseña' : 'Mostrar contraseña';
    if (button) {
        button.setAttribute('title', label);
        button.setAttribute('aria-label', label);
        button.setAttribute('aria-pressed', show ? 'true' : 'false');
        const icon = button.querySelector('.material-symbols-outlined');
        if (icon) icon.textContent = show ? 'visibility_off' : 'visibility';
    }
    input.focus({ preventScroll: true });
    try { input.setSelectionRange(input.value.length, input.value.length); } catch (e) { /* tipo no editable */ }
};

document.addEventListener('click', (event) => {
    const button = event.target instanceof Element ? event.target.closest('.password-toggle[data-target]') : null;
    if (!button) return;
    window.footopiaCare.togglePassword(button.getAttribute('data-target'), button);
});

// Reconectar en móviles sin recargar formularios y sin obligar a alternar la Wi-Fi.
(function watchInteractiveConnection() {
    const sentinel = document.getElementById('components-reconnect-modal');
    const banner = document.getElementById('connection-status');
    const message = document.getElementById('connection-status-message');
    const retry = document.getElementById('connection-retry');
    const draft = document.getElementById('connection-draft-open');
    if (!sentinel || !banner || !message || !retry || !draft) return;
    let state = 'hide', busy = false, checking = false, timer = 0, generation = 0, stateStartedAt = Date.now();
    const terminal = () => ['rejected', 'resume-failed', 'startup-failed'].includes(state);
    const work = () => window.footopiaWorkRecovery;
    const hide = () => {
        banner.hidden = !work()?.hasUnplacedEdits(); retry.hidden = true;
        draft.hidden = !work()?.hasUnplacedEdits();
        if (!draft.hidden) message.textContent = 'Conexión recuperada. Hay texto pendiente de revisar en el borrador.';
    };
    function schedule() {
        clearTimeout(timer);
        if (state !== 'hide' && !document.hidden && (state === 'failed' || terminal() || state === 'show' || state === 'retrying'))
            timer = setTimeout(() => { void recover(); }, 5000);
    }
    function display(next) {
        clearTimeout(timer);
        const token = ++generation;
        if (next === 'hide' || state === 'hide') stateStartedAt = Date.now();
        state = next;
        if (next === 'hide') {
            const resumed = work()?.resume();
            if (resumed) void resumed.then(() => { if (generation === token) hide(); }).catch(() => { if (generation === token) display('failed'); });
            else hide();
            return;
        }
        work()?.pause();
        banner.hidden = false;
        retry.hidden = next !== 'failed';
        draft.hidden = !(terminal() || ((next === 'show' || next === 'retrying') && Date.now() - stateStartedAt >= 90000)) || !work()?.hasWork();
        message.textContent = !navigator.onLine
            ? 'Sin conexión. Puedes seguir escribiendo; recuperaremos la sesión automáticamente.'
            : terminal() && work()?.hasWork()
                ? 'La sesión del servidor terminó. Tu trabajo sigue en esta pestaña; no la recargaremos ni borraremos tus cambios.'
                : terminal()
                    ? 'Recuperando la aplicación automáticamente…'
                    : 'Reconectando automáticamente. Conservamos el formulario y lo escrito.';
        schedule();
    }
    async function recover() {
        if (busy || state === 'hide') return;
        // El evento offline no implica que la LAN esté inaccesible; el intento real decide.
        if (terminal()) {
            // Una página nueva sólo es segura si no existe ningún trabajo pendiente.
            if (checking || !work()) { schedule(); return; }
            if (work().hasWork()) {
                checking = true;
                try { await window.footopiaAppointmentRecovery?.recover(); }
                catch { /* Se conserva la página y se vuelve a intentar. */ }
                finally { checking = false; schedule(); }
                return;
            }
            checking = true;
            const token = generation;
            try {
                const response = await fetch('/health', { credentials: 'same-origin', cache: 'no-store', signal: AbortSignal.timeout(5000) });
                if ((response.status === 401 || (response.ok && !response.redirected && response.headers.get('content-type')?.includes('application/json'))) &&
                    token === generation && terminal() && work() && !work().hasWork()) location.reload();
            } catch { /* El servidor todavía no volvió. */ }
            finally { checking = false; schedule(); }
            return;
        }
        // No se abre otro bucle de SignalR mientras el runtime sigue reintentando.
        // Si lleva 90 segundos bloqueado y no hay trabajo, recuperar el documento
        // con una comprobación real del servidor, incluso si navigator.onLine miente.
        if (state === 'show' || state === 'retrying') {
            if (Date.now() - stateStartedAt >= 90000) {
                if (!work()?.hasWork() && !checking) {
                    checking = true;
                    const token = generation;
                    try {
                        const response = await fetch('/health', { credentials: 'same-origin', cache: 'no-store', signal: AbortSignal.timeout(5000) });
                        if ((response.status === 401 || (response.ok && !response.redirected && response.headers.get('content-type')?.includes('application/json'))) &&
                            token === generation && !work()?.hasWork() && (state === 'show' || state === 'retrying')) location.reload();
                    } catch { /* Un servidor inaccesible no justifica recargar. */ }
                    finally { checking = false; }
                } else if (work()?.hasWork()) {
                    draft.hidden = false;
                    message.textContent = 'La conexión tarda demasiado. Conservamos tus cambios; usa Ver borrador para protegerlos.';
                }
            }
            schedule();
            return;
        }
        if (state !== 'failed') return;
        if (typeof window.Blazor?.reconnect !== 'function') { display('startup-failed'); return; }
        busy = true; retry.disabled = true;
        try {
            const result = await window.Blazor.reconnect();
            display(result === true ? 'hide' : 'rejected');
        } catch { display('failed'); }
        finally { busy = false; retry.disabled = false; schedule(); }
    }
    sentinel.addEventListener('components-reconnect-state-changed', event => {
        if (event.detail?.state) display(event.detail.state);
    });
    // Compatibilidad con cambios de clase del runtime, con un único controlador del aviso.
    new MutationObserver(() => {
        const next = ['resume-failed','rejected','failed','retrying','show','hide']
            .find(value => sentinel.classList.contains('components-reconnect-' + value));
        if (next && next !== state) display(next);
    }).observe(sentinel, { attributes: true, attributeFilter: ['class'] });
    retry.addEventListener('click', () => { void recover(); });
    draft.addEventListener('click', () => work()?.showDraft());
    const resume = () => { if (state !== 'hide') { display(state); void recover(); } };
    window.addEventListener('online', resume);
    // Solo el runtime puede declarar el circuito desconectado. El evento offline
    // puede ser falso en redes locales y no debe bloquear una sesión que funciona.
    window.addEventListener('offline', () => { if (state !== 'hide') display(state); });
    window.addEventListener('pageshow', resume);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) resume(); });
    window.footopiaConnectivity = {
        isReady: false,
        started: () => { window.footopiaConnectivity.isReady = true; },
        startupFailed: () => display('startup-failed')
    };
})();

window.footopiaCare.focusById = function (id) {
    const el = document.getElementById(id);
    if (!el) return false;
    let target = el;
    const inner = el.querySelector && el.querySelector('input, textarea, select');
    if (inner) target = inner;
    // Si el target está dentro de un FcModal, asegura que el modal haga scroll
    target.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
    setTimeout(() => target.focus({ preventScroll: true }), 250);
    if (target.classList) {
        target.classList.add('fc-input--just-focused');
        setTimeout(() => target.classList.remove('fc-input--just-focused'), 1200);
    }
    return true;
};

// Vuelve al inicio de un flujo por pasos al cambiar de paso. Solo actúa en
// pantallas estrechas: en escritorio el formulario cabe entero y mover la vista
// sería un salto gratuito. Devuelve false cuando no hace nada, para que el
// llamador no tenga que consultar el ancho por su cuenta.
window.footopiaCare.scrollToStepStart = function (elementId) {
    if (!window.matchMedia('(max-width: 820px)').matches) return false;

    const target = elementId ? document.getElementById(elementId) : null;
    if (!target) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return true;
    }

    target.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
    return true;
};

// Los campos de fecha y hora solo abren el calendario al pulsar su icono, que es
// un objetivo diminuto en tactil. Con esto se abre pulsando cualquier parte del
// campo. Es una mejora progresiva: si showPicker no existe o el navegador la
// rechaza, el icono nativo sigue funcionando igual que antes.
(function enableFullFieldDatePicker() {
    const PICKER_TYPES = ['date', 'time', 'datetime-local', 'month', 'week'];

    document.addEventListener('click', function (event) {
        const field = event.target;
        if (!(field instanceof HTMLInputElement)) return;
        if (!PICKER_TYPES.includes(field.type)) return;
        if (field.readOnly || field.disabled) return;
        if (typeof field.showPicker !== 'function') return;

        try {
            field.showPicker();
        } catch {
            // Se ignora a proposito: algunos navegadores lo rechazan fuera de un
            // gesto directo sobre el icono, y en ese caso basta el comportamiento nativo.
        }
    });
})();

// Paneles flotantes de los selectores propios de fecha y hora dentro de modales:
// el cuerpo del FcModal desplaza con overflow-y:auto y recortaría un panel
// absoluto, así que el panel es fixed y se ancla al campo desde aquí. Reposiciona
// al desplazar o redimensionar; si no cabe debajo, se abre encima del campo.
(function floatingPanelAnchor() {
    const panels = new Map();

    function untrack(panel) {
        const state = panels.get(panel);
        if (!state) return;
        window.removeEventListener('scroll', state.update, true);
        window.removeEventListener('resize', state.update);
        window.visualViewport?.removeEventListener('resize', state.update);
        window.visualViewport?.removeEventListener('scroll', state.update);
        state.observer.disconnect();
        state.removals.disconnect();
        panels.delete(panel);
    }

    window.footopiaCare.floatingPanelTrack = function (panel, field) {
        if (!panel?.isConnected || !field?.isConnected) return;
        untrack(panel);
        // La capa superior conserva el nodo en Blazor y evita que la animación
        // o el overflow del modal cambien las coordenadas del panel fijo.
        panel.style.margin = '0';
        panel.style.inset = 'auto';
        const topLayer = typeof panel.showPopover === 'function';
        if (topLayer) {
            panel.setAttribute('popover', 'manual');
            if (!panel.matches(':popover-open')) panel.showPopover();
        }
        const update = () => {
            if (!panel.isConnected || !field.isConnected) { untrack(panel); return; }
            const rect = field.getBoundingClientRect();
            const viewport = window.visualViewport;
            const leftEdge = (viewport?.offsetLeft || 0) + 8;
            const topEdge = (viewport?.offsetTop || 0) + 8;
            const rightEdge = leftEdge + (viewport?.width || innerWidth) - 16;
            const bottomEdge = topEdge + (viewport?.height || innerHeight) - 16;
            if (!rect.width || rect.bottom < topEdge || rect.top > bottomEdge) {
                panel.style.visibility = 'hidden'; return;
            }
            panel.style.width = Math.min(300, rightEdge - leftEdge) + 'px';
            panel.style.maxHeight = Math.min(360, bottomEdge - topEdge) + 'px';
            const height = panel.getBoundingClientRect().height;
            const left = Math.max(leftEdge, Math.min(rect.left, rightEdge - panel.getBoundingClientRect().width));
            const below = bottomEdge - rect.bottom - 6;
            const above = rect.top - topEdge - 6;
            const top = below >= height || below >= above ? rect.bottom + 6 : rect.top - height - 6;
            panel.style.left = left + 'px';
            panel.style.top = Math.max(topEdge, Math.min(top, bottomEdge - height)) + 'px';
            if (!topLayer) {
                // Compatibilidad con navegadores sin Popover API.
                const actual = panel.getBoundingClientRect();
                const scale = actual.width / panel.offsetWidth || 1;
                panel.style.left = (left + (left - actual.left) / scale) + 'px';
                const wantedTop = Math.max(topEdge, Math.min(top, bottomEdge - height));
                panel.style.top = (wantedTop + (wantedTop - actual.top) / scale) + 'px';
            }
            panel.style.visibility = 'visible';
        };
        const observer = new ResizeObserver(update);
        const removals = new MutationObserver(() => {
            if (!panel.isConnected || !field.isConnected) untrack(panel);
        });
        const state = { update, observer, removals };
        panels.set(panel, state);
        removals.observe(document.body, { childList: true, subtree: true });
        observer.observe(field);
        observer.observe(panel);
        const modal = field.closest('.fc-modal');
        if (modal) observer.observe(modal);
        window.addEventListener('scroll', update, true);
        window.addEventListener('resize', update);
        window.visualViewport?.addEventListener('resize', update);
        window.visualViewport?.addEventListener('scroll', update);
        update();
    };
    window.footopiaCare.floatingPanelUntrack = untrack;
})();

// Repone el texto válido en un campo de fecha u hora cuando lo tecleado no se
// puede interpretar. El render de Blazor no basta: el atributo `value` no pisa lo
// que el usuario ya escribió en el campo, así que hay que tocar la propiedad.
window.footopiaCare.restoreField = function (field, value) {
    const input = field && typeof field.querySelector === 'function' ? field.querySelector('input') : null;
    if (input) input.value = value ?? '';
};

// Modulo pesado del escaner bajo demanda: el bloque de cedula vive en
// scan/footopia-scan.js y solo se descarga al abrir el lector. Sin esto, las
// paginas que nunca escanean igual descargarian y parsearian ~60 KB.
let scanJsLoading = null;
window.footopiaCare.ensureScanJs = function () {
    if (window.footopiaCare.cedula) return Promise.resolve(true);
    if (!scanJsLoading) {
        scanJsLoading = new Promise((resolve, reject) => {
            const s = document.createElement('script');
            s.src = '/scan/footopia-scan.js';
            s.async = true;
            s.onload = () => resolve(true);
            s.onerror = () => { scanJsLoading = null; reject(new Error('No se pudo cargar el lector.')); };
            document.head.appendChild(s);
        });
    }
    return scanJsLoading;
};

// Pad de firma para consentimientos: dibujo tactil/raton, deteccion de lienzo
// vacio y extraccion de la imagen real. Sin esto la firma seria una ruta ficticia.
(function signaturePad() {
    const pads = {};
    function setup(canvas) {
        if (!canvas || canvas.dataset.sigReady === '1') return null;
        const state = { drawn: false, drawing: false, last: null };
        const ctx = canvas.getContext('2d');
        const scale = window.devicePixelRatio || 1;
        const w = canvas.width, h = canvas.height;
        canvas.width = w * scale; canvas.height = h * scale;
        canvas.style.aspectRatio = w + ' / ' + h;
        ctx.scale(scale, scale);
        ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.strokeStyle = '#111827';
        function pos(e) { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) * (w / r.width), y: (e.clientY - r.top) * (h / r.height) }; }
        canvas.addEventListener('pointerdown', e => { canvas.setPointerCapture(e.pointerId); state.drawing = true; state.last = pos(e); });
        canvas.addEventListener('pointermove', e => { if (!state.drawing) return; const p = pos(e); ctx.beginPath(); ctx.moveTo(state.last.x, state.last.y); ctx.lineTo(p.x, p.y); ctx.stroke(); state.last = p; state.drawn = true; });
        const stop = () => { state.drawing = false; };
        canvas.addEventListener('pointerup', stop);
        canvas.addEventListener('pointercancel', stop);
        canvas.dataset.sigReady = '1';
        pads[canvas.id] = { canvas, ctx, state, w, h, scale };
        return pads[canvas.id];
    }
    window.footopiaCare.signatureInit = function (id) { return !!setup(document.getElementById(id)); };
    window.footopiaCare.signatureIsEmpty = function (id) { const p = pads[id] || setup(document.getElementById(id)); return !p || !p.state.drawn; };
    window.footopiaCare.signatureClear = function (id) { const p = pads[id] || setup(document.getElementById(id)); if (!p) return; p.ctx.save(); p.ctx.setTransform(1, 0, 0, 1, 0, 0); p.ctx.clearRect(0, 0, p.canvas.width, p.canvas.height); p.ctx.restore(); p.state.drawn = false; };
    // La firma sale con fondo transparente y recortada al trazo.
    //
    // Antes se rellenaba de blanco y se exportaba el lienzo entero: sobre la
    // hoja del consentimiento eso dibujaba un recuadro blanco tapando la línea,
    // y como el trazo ocupa una parte pequeña del recuadro, al ajustarlo al alto
    // de la línea la firma quedaba diminuta.
    window.footopiaCare.signatureDataUrl = function (id) {
        const p = pads[id] || setup(document.getElementById(id));
        if (!p || !p.state.drawn) return null;

        const source = p.canvas;
        const ctx = source.getContext('2d');
        let pixels;
        try { pixels = ctx.getImageData(0, 0, source.width, source.height).data; }
        catch { return source.toDataURL('image/png'); }

        // Recuadro mínimo que contiene tinta.
        let minX = source.width, minY = source.height, maxX = -1, maxY = -1;
        for (let y = 0; y < source.height; y++) {
            for (let x = 0; x < source.width; x++) {
                if (pixels[(y * source.width + x) * 4 + 3] > 8) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX < 0) return null;

        const margin = Math.round(6 * p.scale);
        minX = Math.max(0, minX - margin);
        minY = Math.max(0, minY - margin);
        maxX = Math.min(source.width - 1, maxX + margin);
        maxY = Math.min(source.height - 1, maxY + margin);

        const out = document.createElement('canvas');
        out.width = maxX - minX + 1;
        out.height = maxY - minY + 1;
        out.getContext('2d').drawImage(
            source,
            minX, minY, out.width, out.height,
            0, 0, out.width, out.height);

        return out.toDataURL('image/png');
    };
})();

// Anti-doble-POST en formularios SSR (Login, Setup): al enviar por POST clásico
// la página recarga, así que el botón puede bloquearse sin re-habilitación.
// Solo method="post": los formularios interactivos de Blazor no lo usan.
document.addEventListener('submit', function (event) {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.method.toLowerCase() !== 'post') return;
    const btn = form.querySelector('button[type=submit]');
    if (btn) btn.disabled = true;
});

// Atajo ⌘K / Ctrl+K anunciado en la pastilla del buscador global: lleva el foco
// al campo sin pasar por Blazor. No hace nada si ya se escribe en un campo.
(function globalSearchShortcut() {
    document.addEventListener('keydown', function (event) {
        if ((event.metaKey || event.ctrlKey) && !event.shiftKey && !event.altKey && (event.key === 'k' || event.key === 'K')) {
            const active = document.activeElement;
            if (active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement || active instanceof HTMLSelectElement || (active && active.isContentEditable)) return;
            const search = document.getElementById('globalSearchInput');
            if (!search) return;
            event.preventDefault();
            search.focus();
        }
    });
})();


// Campos que solo admiten ciertos caracteres: cédula, códigos postales y
// teléfonos. Se filtra en la fase de captura, antes de que Blazor lea el
// evento, para que el servidor reciba ya el valor limpio y no haya que
// devolverlo corregido en un segundo render.
//
// Va aquí y no en cada componente porque el atributo marca la intención
// (data-fc-input="digits") y cualquier campo nuevo lo hereda sin código.
(function restrictedInputs() {
    const FILTERS = {
        // Cédula, código postal: solo dígitos.
        digits: value => value.replace(/\D+/g, ''),
        // Teléfono: dígitos y los separadores que la gente escribe de verdad.
        phone: value => value.replace(/[^\d+()\-. ]+/g, '')
    };

    document.addEventListener('input', function (event) {
        const el = event.target;
        if (!(el instanceof HTMLInputElement)) return;

        const filter = FILTERS[el.dataset.fcInput];
        if (!filter) return;

        const cleaned = filter(el.value);
        if (cleaned === el.value) return;

        // Se conserva la posición del cursor descontando lo que se descartó a
        // su izquierda; si no, escribir en mitad del número saltaría al final.
        const caret = el.selectionStart ?? el.value.length;
        const removedBefore = el.value.slice(0, caret).length - filter(el.value.slice(0, caret)).length;
        el.value = cleaned;
        try { el.setSelectionRange(caret - removedBefore, caret - removedBefore); }
        catch { /* algunos tipos de input no admiten selección */ }
    }, true);
})();



window.footopiaCare.isCompactViewport = function () { return window.matchMedia("(max-width: 1199px)").matches; };

// Mantiene el tabulador dentro del diálogo y devuelve el foco a quien lo abrió.
window.footopiaCare.modalFocus = (() => {
    const openers = new Map();
    const targets = root => [...root.querySelectorAll('button:not(:disabled), a[href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex="0"]')]
        .filter(el => el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden' && el.getAttribute('aria-disabled') !== 'true');
    document.addEventListener('keydown', event => {
        if (event.key !== 'Tab') return;
        const modals = [...document.querySelectorAll('.fc-modal[aria-modal="true"]')];
        const modal = modals.at(-1);
        if (!modal) return;
        const items = targets(modal);
        const first = items[0], last = items.at(-1);
        if (!first) { event.preventDefault(); modal.focus(); return; }
        const active = document.activeElement;
        if (!modal.contains(active) || active === modal || (event.shiftKey && active === first)) {
            event.preventDefault(); (event.shiftKey ? last : first).focus();
        } else if (!event.shiftKey && active === last) {
            event.preventDefault(); first.focus();
        }
    }, true);
    return {
        open(id) { openers.set(id, document.activeElement); },
        close(id) { const target = openers.get(id); openers.delete(id); if (target?.isConnected) target.focus({preventScroll:true}); }
    };
})();

// Disclosures nativos: teclado y clic fuera conservan el comportamiento del navegador.
window.footopiaCare.closeDisclosure = function (element) {
    const details = element?.closest("details");
    if (!details) return;
    details.open = false;
    details.querySelector("summary")?.focus();
};
document.addEventListener("click", function (event) {
    document.querySelectorAll("details[data-fc-disclosure][open]").forEach(details => {
        if (!details.contains(event.target) || event.target.closest(".detail-more-item")) details.open = false;
    });
});
document.addEventListener("keydown", function (event) {
    if (event.key !== "Escape") return;
    const details = event.target.closest?.("details[data-fc-disclosure][open]");
    if (details) { details.open = false; details.querySelector("summary")?.focus(); event.preventDefault(); }
});

window.footopiaCare.focusFirstInvalid = function(rootId) {
    const root = document.getElementById(rootId) || document;
    const field = root.querySelector('[aria-invalid="true"]');
    if (!field) return;
    field.focus(); field.scrollIntoView({block:'center',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
};

