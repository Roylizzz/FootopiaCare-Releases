-- Auditoría D: la identidad local del soporte de pago para la sincronización era su rowid, que un VACUUM puede
-- renumerar (la clave primaria es un UUID de texto). Se añade una clave entera estable inicializada con el rowid actual,
-- de modo que todas las identidades ya acordadas en sync_ids siguen apuntando al mismo soporte.
ALTER TABLE sale_payment_supports ADD COLUMN sync_key INTEGER;
UPDATE sale_payment_supports SET sync_key = rowid;
CREATE UNIQUE INDEX uq_sale_payment_supports_sync_key ON sale_payment_supports (sync_key);
CREATE TRIGGER tr_sale_payment_supports_sync_key AFTER INSERT ON sale_payment_supports WHEN NEW.sync_key IS NULL
BEGIN
  UPDATE sale_payment_supports SET sync_key = (SELECT COALESCE(MAX(sync_key), 0) + 1 FROM sale_payment_supports) WHERE rowid = NEW.rowid;
END;
