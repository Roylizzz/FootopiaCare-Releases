-- Registro durable anterior a la escritura de archivos y sellado frente a confirmaciones tardías.
CREATE TABLE patient_file_uploads (
 id TEXT PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), patient_id INTEGER NOT NULL REFERENCES patients(id),
 kind TEXT NOT NULL CHECK(kind IN ('photo','document')), file_name TEXT NOT NULL, storage_path TEXT NOT NULL UNIQUE,
 thumbnail_path TEXT NOT NULL DEFAULT '', raw_hash TEXT NOT NULL, file_hash TEXT NOT NULL DEFAULT '', metadata_json TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('Receiving','Staged','Saved','Acknowledged','Resolved','Failed')), result_id INTEGER,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX ix_file_upload_pending ON patient_file_uploads(owner_id,patient_id,kind,status);
CREATE UNIQUE INDEX uq_patient_photo_storage ON patient_photos(storage_path);
CREATE UNIQUE INDEX uq_patient_document_storage ON patient_documents(storage_path);
ALTER TABLE form_responses ADD COLUMN template_snapshot TEXT NOT NULL DEFAULT '';
ALTER TABLE form_responses ADD COLUMN recorded_by TEXT NOT NULL DEFAULT '';
-- La cola usada por el worker no existía: los recordatorios originales siguen en automatic_email_jobs.
CREATE TABLE email_jobs (
 id TEXT PRIMARY KEY, recipient TEXT NOT NULL, subject TEXT NOT NULL, body_text TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Processing','Sent','Failed')),
 due_at TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, sent_at TEXT, last_error TEXT,
 requested_by INTEGER REFERENCES users(id)
);
CREATE TABLE email_job_documents (
 job_id TEXT NOT NULL REFERENCES email_jobs(id) ON DELETE CASCADE,
 document_id INTEGER NOT NULL REFERENCES patient_documents(id), patient_id INTEGER NOT NULL REFERENCES patients(id),
 PRIMARY KEY(job_id,document_id)
);
ALTER TABLE document_upload_cleanup ADD COLUMN cleaned_at TEXT;
