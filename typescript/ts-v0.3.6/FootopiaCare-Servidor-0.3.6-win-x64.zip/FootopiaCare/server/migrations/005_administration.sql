-- Concurrencia y evidencia de recuperaciÃ³n, sin alterar migraciones publicadas.
ALTER TABLE users ADD COLUMN version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE backup_runs ADD COLUMN files_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE backup_runs ADD COLUMN size_bytes INTEGER NOT NULL DEFAULT 0;
ALTER TABLE backup_runs ADD COLUMN checked_at TEXT;
ALTER TABLE backup_runs ADD COLUMN recovery_json TEXT;
ALTER TABLE backup_runs ADD COLUMN external_path TEXT;
ALTER TABLE backup_runs ADD COLUMN external_status TEXT NOT NULL DEFAULT 'NotConfigured';
ALTER TABLE backup_runs ADD COLUMN state TEXT NOT NULL DEFAULT 'Completed';
UPDATE backup_runs SET state=status;
