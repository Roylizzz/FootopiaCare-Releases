CREATE TABLE consent_decisions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
 treatment_id INTEGER REFERENCES treatments(id) ON DELETE RESTRICT,
 purpose TEXT NOT NULL CHECK(purpose IN ('Clinical','Data','Photos')),
 decision TEXT NOT NULL CHECK(decision IN ('Accepted','Refused','Revoked')),
 procedure_text TEXT NOT NULL CHECK(length(trim(procedure_text))>0),
 scope TEXT NOT NULL CHECK(length(trim(scope))>0),
 content_text TEXT NOT NULL CHECK(length(trim(content_text))>0),
 content_hash TEXT NOT NULL CHECK(length(content_hash)=64),
 signer_name TEXT NOT NULL,signer_document TEXT NOT NULL DEFAULT '',
 signer_role TEXT NOT NULL CHECK(signer_role IN ('Patient','Representative')),
 relationship TEXT NOT NULL DEFAULT '',recorded_by TEXT NOT NULL,date TEXT NOT NULL,
 evidence_id INTEGER REFERENCES consents(id) ON DELETE RESTRICT,
 related_decision_id INTEGER REFERENCES consent_decisions(id) ON DELETE RESTRICT,
 notes TEXT NOT NULL DEFAULT '',
 CHECK(purpose<>'Clinical' OR treatment_id IS NOT NULL),
 CHECK(decision<>'Accepted' OR evidence_id IS NOT NULL),
 CHECK((decision='Revoked')=(related_decision_id IS NOT NULL)),
 CHECK(signer_role<>'Representative' OR (length(trim(signer_document))>0 AND length(trim(relationship))>0))
);
CREATE INDEX ix_consent_decisions_patient ON consent_decisions(patient_id,date,id);
CREATE INDEX ix_consent_decisions_treatment ON consent_decisions(treatment_id,date,id);
CREATE TRIGGER tr_consent_decisions_update BEFORE UPDATE ON consent_decisions BEGIN SELECT RAISE(ABORT,'Las decisiones registradas no se pueden modificar.'); END;
CREATE TRIGGER tr_consent_decisions_delete BEFORE DELETE ON consent_decisions BEGIN SELECT RAISE(ABORT,'Las decisiones registradas no se pueden eliminar.'); END;
CREATE TRIGGER tr_consent_decisions_owner BEFORE INSERT ON consent_decisions WHEN (NEW.treatment_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM treatments WHERE id=NEW.treatment_id AND patient_id=NEW.patient_id)) OR (NEW.evidence_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM consents WHERE id=NEW.evidence_id AND patient_id=NEW.patient_id)) OR (NEW.related_decision_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM consent_decisions WHERE id=NEW.related_decision_id AND patient_id=NEW.patient_id AND treatment_id IS NEW.treatment_id AND purpose=NEW.purpose AND decision='Accepted')) BEGIN SELECT RAISE(ABORT,'La decisión y su evidencia deben corresponder al mismo paciente y ciclo.'); END;
CREATE TABLE sync_ids_care (entity TEXT NOT NULL CHECK(entity IN ('patients','discount_events','form_templates','consent_template_versions','schedule_exceptions','products','settings','recurrence_series','ongoing_recurrences','patient_discount_benefits','appointments','wait_list_entries','clinical_attentions','treatments','treatment_sessions','follow_ups','form_responses','patient_notes','tasks','sales','sale_lines','payments','inventory_movements','consents','consent_contents','patient_documents','patient_photos','product_photos','sale_payment_supports','consent_decisions')),local_id INTEGER NOT NULL,global_id TEXT NOT NULL UNIQUE,PRIMARY KEY(entity,local_id));
INSERT INTO sync_ids_care SELECT entity,local_id,global_id FROM sync_ids;
DROP TABLE sync_ids;
ALTER TABLE sync_ids_care RENAME TO sync_ids;
