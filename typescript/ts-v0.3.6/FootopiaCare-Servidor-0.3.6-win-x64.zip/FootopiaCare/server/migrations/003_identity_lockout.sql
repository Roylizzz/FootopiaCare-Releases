-- Identidad como en el original (ASP.NET Identity): la cuenta es el correo
-- (`users.username` guarda el correo, igual que UserName = Email) y cinco
-- intentos fallidos seguidos bloquean la cuenta durante quince minutos.
ALTER TABLE users ADD COLUMN access_failed_count INTEGER NOT NULL DEFAULT 0 CHECK (access_failed_count >= 0);
ALTER TABLE users ADD COLUMN lockout_end TEXT;
