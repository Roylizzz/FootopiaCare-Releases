-- Lista de espera con resolución explícita: una solicitud queda Pendiente,
-- Citada (vinculada a la cita que la atiende) o Retirada. Resolver nunca borra;
-- se conserva quién y cuándo. Las solicitudes existentes siguen Pendiente.
ALTER TABLE wait_list_entries ADD COLUMN appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL;
ALTER TABLE wait_list_entries ADD COLUMN resolved_at TEXT;
ALTER TABLE wait_list_entries ADD COLUMN resolved_by TEXT NOT NULL DEFAULT '';
-- Una cita resuelve como mucho una solicitud.
CREATE UNIQUE INDEX uq_wait_list_appointment ON wait_list_entries(appointment_id) WHERE appointment_id IS NOT NULL;
CREATE INDEX ix_wait_list_resolved ON wait_list_entries(resolved_at DESC, id DESC) WHERE status <> 'Pendiente';
