-- =============================================================================
-- FootopiaCare · esquema SQLite 002 — comercio, operación, descuentos,
-- consentimientos, mensajería, respaldos y recibos técnicos de reintento.
--
-- Migración 1:1 del esquema PostgreSQL original (Database/Tables/*.sql).
-- =============================================================================

-- ------------------------------------------------------------------ comercio ---
CREATE TABLE products (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  code          TEXT    NOT NULL UNIQUE,
  name          TEXT    NOT NULL,
  category      TEXT    NOT NULL DEFAULT 'General',
  price         INTEGER NOT NULL CHECK (price >= 0 AND price <= 1000000000),
  stock         INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0 AND stock <= 1000000),
  minimum_stock INTEGER NOT NULL DEFAULT 0 CHECK (minimum_stock >= 0 AND minimum_stock <= 1000000),
  active        INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  photo_path    TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX ix_products_name ON products (name, id);
CREATE INDEX ix_products_low_stock ON products (stock, minimum_stock) WHERE active = 1;

CREATE TABLE sales (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  code           TEXT    NOT NULL UNIQUE,
  patient_id     INTEGER NULL REFERENCES patients(id) ON DELETE RESTRICT,
  patient_name   TEXT    NOT NULL DEFAULT '',
  sale_date      TEXT    NOT NULL,
  total          INTEGER NOT NULL CHECK (total >= 0 AND total <= 1000000000),
  payment_method TEXT    NOT NULL,
  status         TEXT    NOT NULL CHECK (status IN ('Pending','Paid','Cancelled'))
);
CREATE INDEX ix_sales_date ON sales (sale_date DESC, id DESC);
CREATE INDEX ix_sales_patient ON sales (patient_id, sale_date DESC) WHERE patient_id IS NOT NULL;

CREATE TABLE sale_lines (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id       INTEGER NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
  product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  product_name  TEXT    NOT NULL,
  unit_price    INTEGER NOT NULL CHECK (unit_price >= 0 AND unit_price <= 1000000000),
  quantity      INTEGER NOT NULL CHECK (quantity > 0 AND quantity <= 1000000),
  UNIQUE (sale_id, product_id)
);
CREATE INDEX ix_sale_lines_sale ON sale_lines (sale_id, id);

CREATE TABLE inventory_movements (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  movement_date TEXT    NOT NULL,
  quantity      INTEGER NOT NULL CHECK (quantity <> 0 AND quantity BETWEEN -1000000 AND 1000000),
  reason        TEXT    NOT NULL,
  user_name     TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX ix_inventory_movements_product_date ON inventory_movements (product_id, movement_date DESC, id DESC);

CREATE TABLE payments (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id     INTEGER NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  sale_id        INTEGER NULL REFERENCES sales(id) ON DELETE RESTRICT,
  appointment_id INTEGER NULL REFERENCES appointments(id) ON DELETE RESTRICT,
  payment_date   TEXT    NOT NULL,
  concept        TEXT    NOT NULL,
  value          INTEGER NOT NULL CHECK (value > 0 AND value <= 1000000000),
  method         TEXT    NOT NULL,
  status         TEXT    NOT NULL CHECK (status IN ('Paid','Partial','Pending','Cancelled')),
  notes          TEXT    NOT NULL DEFAULT '',
  -- Un pago se refiere a una venta o a una cita, nunca a las dos.
  CONSTRAINT ck_payments_single_reference CHECK (NOT (sale_id IS NOT NULL AND appointment_id IS NOT NULL))
);
CREATE INDEX ix_payments_patient_date ON payments (patient_id, payment_date DESC, id DESC);
CREATE INDEX ix_payments_sale ON payments (sale_id) WHERE sale_id IS NOT NULL;
CREATE INDEX ix_payments_appointment ON payments (appointment_id) WHERE appointment_id IS NOT NULL;

-- Clave única compuesta que exige el soporte de pago (fk (sale_id, payment_id)).
CREATE UNIQUE INDEX uq_payments_sale_id_id ON payments (sale_id, id);

CREATE TABLE sale_payment_supports (
  id            TEXT    PRIMARY KEY,
  sale_id       INTEGER NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
  payment_id    INTEGER NULL,
  file_name     TEXT    NOT NULL,
  storage_path  TEXT    NOT NULL UNIQUE,
  content_type  TEXT    NOT NULL CHECK (content_type IN ('image/png','image/jpeg','image/webp')),
  content_hash  TEXT    NOT NULL,
  created_at    TEXT    NOT NULL,
  uploaded_by   TEXT    NOT NULL,
  FOREIGN KEY (sale_id, payment_id) REFERENCES payments(sale_id, id) ON DELETE RESTRICT
);
CREATE INDEX ix_sale_payment_supports_sale ON sale_payment_supports (sale_id, created_at DESC);

-- ---------------------------------------------------------------- operación ----
CREATE TABLE tasks (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  title            TEXT    NOT NULL,
  description      TEXT    NOT NULL DEFAULT '',
  responsible_name TEXT    NOT NULL DEFAULT '',
  due_date         TEXT    NOT NULL,
  priority         TEXT    NOT NULL DEFAULT 'Medium' CHECK (priority IN ('Low','Medium','High')),
  is_completed     INTEGER NOT NULL DEFAULT 0 CHECK (is_completed IN (0,1)),
  patient_id       INTEGER REFERENCES patients(id) ON DELETE SET NULL,
  CONSTRAINT ck_tasks_title_not_blank CHECK (trim(title) <> '')
);
CREATE INDEX ix_tasks_due_date_is_completed ON tasks (due_date, is_completed);

CREATE TABLE patient_notes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  date       TEXT    NOT NULL,
  title      TEXT    NOT NULL,
  detail     TEXT    NOT NULL DEFAULT '',
  type       TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX ix_patient_notes_patient_id_date ON patient_notes (patient_id, date);

CREATE TABLE patient_photos (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id           INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  clinical_attention_id INTEGER REFERENCES clinical_attentions(id) ON DELETE SET NULL,
  date                 TEXT    NOT NULL,
  file_name            TEXT    NOT NULL,
  storage_path         TEXT    NOT NULL,
  category             TEXT    NOT NULL DEFAULT '',
  notes                TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX ix_patient_photos_patient_id_date ON patient_photos (patient_id, date);
CREATE INDEX ix_patient_photos_attention ON patient_photos (clinical_attention_id) WHERE clinical_attention_id IS NOT NULL;

-- Limpieza durable del sistema de archivos tras borrar la fila de la foto,
-- incluso si el proceso se reinicia (011_photo_cleanup.sql).
CREATE TABLE patient_photo_cleanup (
  storage_path TEXT PRIMARY KEY,
  queued_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

CREATE TABLE notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT    NOT NULL,
  title      TEXT    NOT NULL,
  message    TEXT    NOT NULL DEFAULT '',
  type       TEXT    NOT NULL DEFAULT 'System',
  is_read    INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0,1)),
  resolved_at TEXT   NULL,
  patient_id INTEGER REFERENCES patients(id) ON DELETE SET NULL
);
CREATE INDEX ix_notifications_is_read_created_at ON notifications (is_read, created_at);

CREATE TABLE patient_documents (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id   INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  file_name    TEXT    NOT NULL,
  storage_path TEXT    NOT NULL,
  type         TEXT    NOT NULL DEFAULT '',
  date         TEXT    NOT NULL,
  notes        TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX ix_patient_documents_patient_id_date ON patient_documents (patient_id, date);

-- Camino único sellado antes de borrar una carga sin referencia: una creación
-- tardía no puede volver a enlazar un archivo ya limpiado.
CREATE TABLE document_upload_cleanup (
  storage_path TEXT PRIMARY KEY
);

CREATE TABLE consents (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id        INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  type              TEXT    NOT NULL,
  version           TEXT    NOT NULL,
  signature_path    TEXT    NOT NULL,
  date              TEXT    NOT NULL,
  professional_name TEXT    NOT NULL DEFAULT '',
  notes             TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX ix_consents_patient_id_date ON consents (patient_id, date);

-- Recibos técnicos de reintento de consentimiento (sin firma ni texto clínico).
CREATE TABLE consent_operations (
  operation_id TEXT    PRIMARY KEY,
  fingerprint  TEXT    NOT NULL CHECK (length(fingerprint) = 64),
  consent_id   INTEGER NOT NULL UNIQUE REFERENCES consents(id) ON DELETE CASCADE
);

CREATE TABLE wait_list_entries (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id        INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  patient_name      TEXT    NOT NULL DEFAULT '',
  service_name      TEXT    NOT NULL,
  professional_name TEXT    NOT NULL DEFAULT '',
  from_date         TEXT    NOT NULL,
  to_date           TEXT    NOT NULL,
  status            TEXT    NOT NULL DEFAULT 'Pendiente',
  created_at        TEXT    NOT NULL,
  CONSTRAINT ck_wait_list_date_range CHECK (to_date >= from_date)
);
CREATE INDEX ix_wait_list_entries_status_from_date ON wait_list_entries (status, from_date);

CREATE TABLE form_templates (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,
  description TEXT    NOT NULL DEFAULT '',
  fields_json TEXT    NOT NULL DEFAULT '[]',
  active      INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at  TEXT    NOT NULL
);

CREATE TABLE form_responses (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id   INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  template_id  INTEGER NOT NULL REFERENCES form_templates(id) ON DELETE RESTRICT,
  answers_json TEXT    NOT NULL DEFAULT '{}',
  submitted_at TEXT    NOT NULL,
  status       TEXT    NOT NULL DEFAULT 'Completado'
);
CREATE INDEX ix_form_responses_patient_id_submitted_at ON form_responses (patient_id, submitted_at);

CREATE TABLE services (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  name             TEXT    NOT NULL,
  price            INTEGER NOT NULL DEFAULT 0 CHECK (price >= 0 AND price <= 1000000000),
  duration_minutes INTEGER NOT NULL DEFAULT 45 CHECK (duration_minutes BETWEEN 1 AND 480),
  agenda_color     TEXT    NOT NULL DEFAULT 'blue',
  active           INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  CONSTRAINT uq_services_name UNIQUE (name)
);

-- Excepciones por fecha del horario (cierres y jornadas especiales).
CREATE TABLE schedule_exceptions (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  day        TEXT    NOT NULL,
  closed     INTEGER NOT NULL DEFAULT 1 CHECK (closed IN (0,1)),
  start_time TEXT    NULL,
  end_time   TEXT    NULL,
  note       TEXT    NOT NULL DEFAULT '',
  CONSTRAINT ck_schedule_exception_range CHECK (closed = 1 OR (start_time IS NOT NULL AND end_time IS NOT NULL AND start_time < end_time))
);
CREATE UNIQUE INDEX uq_schedule_exceptions_day ON schedule_exceptions (day);

-- ---------------------------------------------------------------- descuentos ---
CREATE TABLE discount_events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,
  percent     INTEGER NOT NULL,
  starts_at   TEXT    NOT NULL,
  ends_at     TEXT    NOT NULL,
  active      INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  description TEXT    NOT NULL DEFAULT '',
  CONSTRAINT ck_discount_events_name CHECK (trim(name) <> ''),
  CONSTRAINT ck_discount_events_percent CHECK (percent > 0 AND percent <= 10000),
  CONSTRAINT ck_discount_events_range CHECK (starts_at < ends_at)
);
CREATE INDEX ix_discount_events_window ON discount_events (active, starts_at, ends_at);

CREATE TABLE patient_discount_benefits (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id      INTEGER NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  percent         INTEGER NOT NULL CHECK (percent > 0 AND percent <= 10000),
  reason          TEXT    NOT NULL,
  source_patient_id INTEGER NULL REFERENCES patients(id) ON DELETE RESTRICT,
  created_at      TEXT    NOT NULL,
  used_at         TEXT    NULL,
  used_appointment_id INTEGER NULL REFERENCES appointments(id) ON DELETE RESTRICT,
  CONSTRAINT ck_patient_discount_reason CHECK (trim(reason) <> '')
);
CREATE INDEX ix_patient_discount_pending ON patient_discount_benefits (patient_id, created_at, id) WHERE used_at IS NULL;

-- --------------------------------------------------------------- mensajería ----
-- Cola persistente. Sólo referencias y estado técnico; los adjuntos siguen en Storage.
CREATE TABLE automatic_email_jobs (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  event_key              TEXT    NOT NULL UNIQUE,
  kind                   TEXT    NOT NULL CHECK (kind IN ('AppointmentConfirmation','AppointmentReminder','PatientDocuments')),
  patient_id             INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  appointment_id         INTEGER NULL REFERENCES appointments(id) ON DELETE CASCADE,
  appointment_starts_at  TEXT    NULL,
  status                 TEXT    NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending','Processing','Sent','Skipped','Failed')),
  created_at             TEXT    NOT NULL,
  available_at           TEXT    NOT NULL,
  attempts               INTEGER NOT NULL DEFAULT 0,
  lease_token            TEXT    NULL,
  lease_until            TEXT    NULL,
  sent_at                TEXT    NULL,
  last_error_code        TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX ix_automatic_email_due ON automatic_email_jobs (available_at, id) WHERE status IN ('Pending','Processing');
CREATE INDEX ix_automatic_email_appointment ON automatic_email_jobs (appointment_id, kind, sent_at);

-- Progreso de tutoriales interactivos por usuario. Sólo datos técnicos.
CREATE TABLE tutorial_progress (
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tutorial_id  TEXT    NOT NULL,
  current_step INTEGER NOT NULL DEFAULT 0 CHECK (current_step >= 0),
  status       TEXT    NOT NULL DEFAULT 'InProgress' CHECK (status IN ('NotStarted','InProgress','Completed')),
  completed_at TEXT    NULL,
  updated_at   TEXT    NOT NULL,
  PRIMARY KEY (user_id, tutorial_id)
);
CREATE INDEX ix_tutorial_progress_user_id ON tutorial_progress (user_id);

-- -------------------------------------------------- recibos técnicos de pago ---
-- Recibos técnicos de reintento genéricos: evitan duplicar una escritura
-- sensible (cobro, consentimiento, sesión, venta) cuando el navegador reintenta.
-- No son un registro de auditoría ni contienen datos clínicos.
CREATE TABLE operation_receipts (
  id            TEXT    PRIMARY KEY,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  action        TEXT    NOT NULL,
  operation_key TEXT    NOT NULL,
  request_hash  TEXT    NOT NULL,
  result_json   TEXT    NOT NULL,
  created_at    TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (user_id, action, operation_key)
);

CREATE TABLE payment_operations (
  operation_id TEXT    PRIMARY KEY,
  fingerprint  TEXT    NOT NULL CHECK (length(fingerprint) = 64),
  payment_id   INTEGER NOT NULL UNIQUE REFERENCES payments(id) ON DELETE CASCADE
);

-- Estado temporal para recuperar intentos propios tras cerrar el navegador.
CREATE TABLE pending_payment_attempts (
  operation_id TEXT    PRIMARY KEY,
  owner_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  payload      TEXT    NULL,
  cancelled    INTEGER NOT NULL DEFAULT 0 CHECK (cancelled IN (0,1)),
  created_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);
CREATE INDEX ix_pending_payment_owner ON pending_payment_attempts (owner_id) WHERE cancelled = 0;

-- Recuperación temporal de la nueva cita por usuario y pestaña.
CREATE TABLE appointment_recovery_drafts (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ticket     TEXT    NOT NULL,
  payload    TEXT    NOT NULL,
  expires_at TEXT    NOT NULL,
  PRIMARY KEY (user_id, ticket)
);
CREATE INDEX ix_appointment_recovery_expiry ON appointment_recovery_drafts (expires_at);

-- ------------------------------------------------- contenido de consentimiento --
-- No se atribuye retroactivamente contenido ni aprobación a registros históricos.
CREATE TABLE consent_template_versions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  type        TEXT    NOT NULL,
  version     TEXT    NOT NULL,
  body        TEXT    NOT NULL,
  body_hash   TEXT    NOT NULL,
  created_at  TEXT    NOT NULL,
  created_by  TEXT    NOT NULL,
  approved_at TEXT    NULL,
  approved_by TEXT    NOT NULL DEFAULT '',
  retired_at  TEXT    NULL,
  CONSTRAINT uq_consent_template_type_version UNIQUE (type, version),
  CONSTRAINT ck_consent_template_body CHECK (length(body) > 0 AND length(body) <= 32000)
);
CREATE UNIQUE INDEX uq_consent_template_active ON consent_template_versions (type) WHERE approved_at IS NOT NULL AND retired_at IS NULL;

CREATE TABLE consent_contents (
  consent_id            INTEGER PRIMARY KEY REFERENCES consents(id) ON DELETE RESTRICT,
  template_version_id   INTEGER NULL REFERENCES consent_template_versions(id) ON DELETE RESTRICT,
  accepted_text         TEXT    NOT NULL DEFAULT '',
  content_hash          TEXT    NOT NULL,
  patient_name          TEXT    NOT NULL,
  recorded_by           TEXT    NOT NULL,
  signature_hash        TEXT    NOT NULL DEFAULT '',
  signed_document_path  TEXT    NOT NULL DEFAULT '',
  CONSTRAINT ck_consent_content_source CHECK ((accepted_text <> '' AND template_version_id IS NOT NULL) OR signed_document_path <> ''),
  CONSTRAINT ck_consent_content_hash CHECK (length(content_hash) = 64)
);
CREATE UNIQUE INDEX uq_consent_signed_document ON consent_contents (signed_document_path) WHERE signed_document_path <> '';

-- Inmutabilidad de consentimientos (equivalentes a los disparadores
-- fn_consent_template_immutable, fn_consent_content_immutable y
-- fn_consent_record_immutable del original).
CREATE TRIGGER tr_consent_template_immutable BEFORE UPDATE ON consent_template_versions
BEGIN
  SELECT RAISE(ABORT,'Esta versión es inmutable. Crea una versión nueva.')
  WHERE NEW.type <> OLD.type OR NEW.version <> OLD.version OR NEW.body <> OLD.body
     OR NEW.body_hash <> OLD.body_hash OR NEW.created_at <> OLD.created_at OR NEW.created_by <> OLD.created_by
     OR (OLD.approved_at IS NOT NULL AND (NEW.approved_at IS NOT OLD.approved_at OR NEW.approved_by IS NOT OLD.approved_by));
END;
CREATE TRIGGER tr_consent_content_immutable BEFORE UPDATE ON consent_contents
BEGIN
  SELECT RAISE(ABORT,'El contenido de un consentimiento registrado no se puede sustituir.');
END;
CREATE TRIGGER tr_consent_record_immutable BEFORE UPDATE ON consents
WHEN EXISTS (SELECT 1 FROM consent_contents WHERE consent_id = OLD.id)
BEGIN
  SELECT RAISE(ABORT,'Los datos de un consentimiento vinculado no se pueden sustituir.');
END;

-- ------------------------------------------------------------------ respaldos --
CREATE TABLE backup_runs (
  id               TEXT PRIMARY KEY,
  folder_path      TEXT NOT NULL,
  status           TEXT NOT NULL CHECK (status IN ('Completed','Failed')),
  database_sha256  TEXT,
  manifest_json    TEXT NOT NULL DEFAULT '{}',
  created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX ix_backup_runs_created ON backup_runs (created_at DESC);

-- ------------------------------------------------ semilla de puesta en marcha --
-- Plantilla de la sección «SOLO PARA USO DE LA TÉCNICA DE UÑAS» de la hoja que
-- la clienta firma al abrir su ficha. Sólo se inserta si falta: si la clínica
-- editó las preguntas, el baseline no las pisa al reaplicarse.
INSERT INTO form_templates (name, description, fields_json, active, created_at)
SELECT
  'Ficha técnica de uñas',
  'Sección reservada a la técnica de uñas en la hoja de información. Puede completarse durante o después de la atención.',
  '[
    {"key":"cuticula_calificacion","label":"Calificación de la condición de la cutícula (1-10)","type":"scale"},
    {"key":"cuticula_comentario","label":"Comentario sobre la cutícula","type":"text"},
    {"key":"una_calificacion","label":"Calificación de la condición de la uña (1-10)","type":"scale"},
    {"key":"una_comentario","label":"Comentario sobre la uña","type":"text"},
    {"key":"forma_largo","label":"Forma/largo preferido","type":"text"},
    {"key":"colores_esmalte","label":"Color(es) de esmalte preferido(s)","type":"text"},
    {"key":"servicios_unas","label":"Servicios de uñas","type":"multi","options":["Acrílico","Envolturas","Gel","Manicura","Pedicura"]},
    {"key":"servicios_tipo","label":"Tipo (otro servicio de uñas)","type":"text"},
    {"key":"servicios_otros","label":"Servicios distintos al cuidado de uñas","type":"text"},
    {"key":"reacciones","label":"Reacciones a productos: primers, etc. (si aplica)","type":"textarea"},
    {"key":"comentarios","label":"Comentarios","type":"textarea"}
  ]',
  1,
  (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
WHERE NOT EXISTS (SELECT 1 FROM form_templates WHERE name = 'Ficha técnica de uñas');
