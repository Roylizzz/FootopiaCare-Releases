-- Una reserva de contacto no es un paciente ni una historia clínica.
CREATE TABLE appointment_reservations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 booking_key TEXT NOT NULL UNIQUE,
 attendee_name TEXT NOT NULL CHECK(trim(attendee_name)<>''),
 contact_name TEXT NOT NULL DEFAULT '', contact_phone TEXT NOT NULL, relationship TEXT NOT NULL DEFAULT '',
 service_name TEXT NOT NULL, professional_name TEXT NOT NULL,
 starts_at TEXT NOT NULL, ends_at TEXT NOT NULL CHECK(starts_at<ends_at), notes TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN('Pending','Confirmed','Cancelled','NoShow','Linked')),
 patient_id INTEGER REFERENCES patients(id) ON DELETE RESTRICT,
 original_details TEXT NOT NULL, created_by_name TEXT NOT NULL,
 version INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 CHECK((status='Linked' AND patient_id IS NOT NULL) OR (status<>'Linked' AND patient_id IS NULL))
);
CREATE INDEX ix_reservations_window ON appointment_reservations(starts_at,ends_at);
ALTER TABLE appointments ADD COLUMN reservation_key TEXT;
CREATE UNIQUE INDEX ux_appointments_reservation ON appointments(reservation_key) WHERE reservation_key IS NOT NULL;
CREATE TRIGGER tr_reservation_original BEFORE UPDATE OF booking_key,attendee_name,contact_name,contact_phone,relationship,service_name,professional_name,notes,original_details,created_by_name,created_at ON appointment_reservations
WHEN NEW.booking_key<>OLD.booking_key OR NEW.attendee_name<>OLD.attendee_name OR NEW.contact_name<>OLD.contact_name OR NEW.contact_phone<>OLD.contact_phone OR NEW.relationship<>OLD.relationship OR NEW.service_name<>OLD.service_name OR NEW.professional_name<>OLD.professional_name OR NEW.notes<>OLD.notes OR NEW.original_details<>OLD.original_details OR NEW.created_by_name<>OLD.created_by_name OR NEW.created_at<>OLD.created_at
BEGIN SELECT RAISE(ABORT,'RESERVATION_ORIGINAL_IMMUTABLE'); END;
CREATE TRIGGER tr_reservation_overlap_insert BEFORE INSERT ON appointment_reservations WHEN NEW.status IN('Pending','Confirmed')
BEGIN
 SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS(SELECT 1 FROM appointments a WHERE a.status<>'Cancelled' AND (a.reservation_key IS NULL OR a.reservation_key<>NEW.booking_key) AND lower(trim(a.professional_name))=lower(trim(NEW.professional_name)) AND a.starts_at<NEW.ends_at AND NEW.starts_at<a.ends_at);
 SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS(SELECT 1 FROM appointment_reservations r WHERE r.status IN('Pending','Confirmed') AND lower(trim(r.professional_name))=lower(trim(NEW.professional_name)) AND r.starts_at<NEW.ends_at AND NEW.starts_at<r.ends_at);
END;
CREATE TRIGGER tr_reservation_overlap_update BEFORE UPDATE OF starts_at,ends_at,status ON appointment_reservations WHEN NEW.status IN('Pending','Confirmed')
BEGIN
 SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS(SELECT 1 FROM appointments a WHERE a.status<>'Cancelled' AND (a.reservation_key IS NULL OR a.reservation_key<>NEW.booking_key) AND lower(trim(a.professional_name))=lower(trim(NEW.professional_name)) AND a.starts_at<NEW.ends_at AND NEW.starts_at<a.ends_at);
 SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS(SELECT 1 FROM appointment_reservations r WHERE r.id<>NEW.id AND r.status IN('Pending','Confirmed') AND lower(trim(r.professional_name))=lower(trim(NEW.professional_name)) AND r.starts_at<NEW.ends_at AND NEW.starts_at<r.ends_at);
END;
CREATE TRIGGER tr_appointments_reservation_insert BEFORE INSERT ON appointments WHEN NEW.status<>'Cancelled'
BEGIN SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS(SELECT 1 FROM appointment_reservations r WHERE r.status IN('Pending','Confirmed') AND (NEW.reservation_key IS NULL OR r.booking_key<>NEW.reservation_key) AND lower(trim(r.professional_name))=lower(trim(NEW.professional_name)) AND r.starts_at<NEW.ends_at AND NEW.starts_at<r.ends_at); END;
CREATE TRIGGER tr_appointments_reservation_update BEFORE UPDATE OF starts_at,ends_at,professional_name,status ON appointments WHEN NEW.status<>'Cancelled'
BEGIN SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS(SELECT 1 FROM appointment_reservations r WHERE r.status IN('Pending','Confirmed') AND (NEW.reservation_key IS NULL OR r.booking_key<>NEW.reservation_key) AND lower(trim(r.professional_name))=lower(trim(NEW.professional_name)) AND r.starts_at<NEW.ends_at AND NEW.starts_at<r.ends_at); END;

CREATE TABLE sync_ids_reservations (entity TEXT NOT NULL CHECK(entity IN ('patients','discount_events','form_templates','consent_template_versions','schedule_exceptions','products','settings','recurrence_series','ongoing_recurrences','patient_discount_benefits','appointments','wait_list_entries','clinical_attentions','treatments','treatment_sessions','follow_ups','form_responses','patient_notes','tasks','sales','sale_lines','payments','inventory_movements','consents','consent_contents','patient_documents','patient_photos','product_photos','sale_payment_supports','consent_decisions','appointment_reservations')),local_id INTEGER NOT NULL,global_id TEXT NOT NULL UNIQUE,PRIMARY KEY(entity,local_id));
INSERT INTO sync_ids_reservations SELECT entity,local_id,global_id FROM sync_ids;
DROP TABLE sync_ids;
ALTER TABLE sync_ids_reservations RENAME TO sync_ids;
