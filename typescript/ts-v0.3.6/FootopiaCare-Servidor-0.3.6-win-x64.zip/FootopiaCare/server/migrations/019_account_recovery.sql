CREATE TABLE account_recovery (
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 kind TEXT NOT NULL CHECK(kind IN ('email','offline')),
 proof TEXT NOT NULL,
 expires_ms INTEGER NOT NULL,
 version INTEGER NOT NULL,
 PRIMARY KEY(user_id,kind)
);
CREATE TABLE auth_attempts (
 key TEXT PRIMARY KEY,
 attempts INTEGER NOT NULL,
 until_ms INTEGER NOT NULL
);
