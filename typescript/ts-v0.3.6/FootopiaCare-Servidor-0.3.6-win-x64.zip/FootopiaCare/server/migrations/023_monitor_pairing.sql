-- Códigos de vinculación generados por el Monitor: guardan el origen HTTPS que mostró el QR o el código manual.
-- Los códigos de la versión anterior (generados desde Administración) quedan con origin NULL.
ALTER TABLE sync_pairing_codes ADD COLUMN origin TEXT NULL;
