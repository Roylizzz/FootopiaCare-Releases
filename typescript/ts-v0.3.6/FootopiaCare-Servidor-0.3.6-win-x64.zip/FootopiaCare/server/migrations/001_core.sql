-- =============================================================================
-- FootopiaCare · esquema SQLite 001 — núcleo (identidad, pacientes, agenda,
-- historia clínica, tratamientos y seguimientos).
--
-- Migración 1:1 del esquema PostgreSQL original (Database/Tables/*.sql). Se
-- conserva el mismo modelo de datos, las mismas reglas y los mismos nombres
-- funcionales. Las diferencias con PostgreSQL son sólo de motor:
--   * uuid/integer identity → INTEGER PRIMARY KEY AUTOINCREMENT (identificadores
--     numéricos estables para poder migrar 1:1 conservando los originales).
--   * numeric(12,2) → INTEGER en unidades menores (centavos), sin float.
--   * numeric(5,2) (porcentajes de descuento) → INTEGER en centésimas de
--     porcentaje (basis points): 1550 = 15,50 %. Se conserva la precisión de
--     dos decimales del original sin usar coma flotante.
--   * timestamp without time zone → TEXT ISO local 'YYYY-MM-DDTHH:MM:SS' (hora de
--     pared America/Bogota). Las marcas técnicas usan UTC ISO.
--   * interval → INTEGER de minutos.
--   * jsonb → TEXT con JSON serializado.
--   * pg_advisory_xact_lock + trigger de solape → disparadores de solape + BEGIN
--     IMMEDIATE en las escrituras críticas.
--   * columnas GENERATED STORED → disparadores equivalentes.
-- =============================================================================

-- ---------------------------------------------------------------- identidad ---
-- Equivalente a AspNetUsers/AspNetRoles de Identity. El original tiene un único
-- rol funcional («Administrador», que abre Administración) más un perfil de
-- permisos por cuenta. `is_admin` reproduce ese rol; `profile` el perfil de
-- permisos por defecto (reception/clinical/full/administration).
CREATE TABLE users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT    NOT NULL COLLATE NOCASE,
  full_name     TEXT    NOT NULL DEFAULT '',
  password_hash TEXT    NOT NULL,
  profile       TEXT    NOT NULL DEFAULT 'reception' CHECK (profile IN ('reception','clinical','full','administration')),
  active        INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  is_admin      INTEGER NOT NULL DEFAULT 0 CHECK (is_admin IN (0,1)),
  created_at    TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  CHECK (length(trim(username)) > 0)
);
CREATE UNIQUE INDEX uq_users_username ON users (username);

-- Permisos funcionales concedidos además del perfil de rol
-- (reception, clinical, commerce, export, photos.delete, administration).
CREATE TABLE user_permissions (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  permission TEXT    NOT NULL CHECK (permission IN ('reception','clinical','commerce','export','photos.delete','administration')),
  granted    INTEGER NOT NULL CHECK (granted IN (0,1)),
  PRIMARY KEY (user_id, permission)
);

CREATE TABLE sessions (
  id         TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX ix_sessions_expires ON sessions (expires_at);

-- --------------------------------------------------------------- ajustes ------
-- Ajustes de la clínica en pares clave/valor. El horario semanal se guarda como
-- JSON con la misma forma que WeeklyBusinessHours (7 días, franjas ordenadas).
CREATE TABLE settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- --------------------------------------------------------------- pacientes -----
-- Equivale a la tabla patients (001_patients.sql) con todas sus columnas
-- aditivas: perfil de la hoja INFORMACIÓN, descubrimiento, disponibilidad y
-- frecuencia de visita. `version` la incrementa un disparador en cada UPDATE.
CREATE TABLE patients (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  code                  TEXT    NOT NULL,
  first_name            TEXT    NOT NULL,
  last_name             TEXT    NOT NULL,
  document_number       TEXT    NOT NULL DEFAULT '',
  birth_date            TEXT    NOT NULL,
  gender                TEXT    NOT NULL DEFAULT 'Unspecified' CHECK (gender IN ('Unspecified','Female','Male')),
  phone                 TEXT    NOT NULL DEFAULT '',
  phone_normalized      TEXT    NOT NULL DEFAULT '',
  email                 TEXT    NOT NULL DEFAULT '',
  general_notes         TEXT    NOT NULL DEFAULT '',
  status                TEXT    NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Inactive')),
  registered_at         TEXT    NOT NULL,
  address               TEXT    NOT NULL DEFAULT '',
  city                  TEXT    NOT NULL DEFAULT '',
  state_province        TEXT    NOT NULL DEFAULT '',
  postal_code           TEXT    NOT NULL DEFAULT '',
  home_phone            TEXT    NOT NULL DEFAULT '',
  work_phone            TEXT    NOT NULL DEFAULT '',
  occupation            TEXT    NOT NULL DEFAULT '',
  employer              TEXT    NOT NULL DEFAULT '',
  allergies             TEXT    NOT NULL DEFAULT '',
  personal_products     TEXT    NOT NULL DEFAULT '',
  commercial_products   TEXT    NOT NULL DEFAULT '',
  referred_by           TEXT    NOT NULL DEFAULT '',
  referrer_patient_id   INTEGER NULL REFERENCES patients(id) ON DELETE RESTRICT,
  preferred_day         TEXT    NOT NULL DEFAULT '',
  discovery_source      TEXT    NOT NULL DEFAULT '' CHECK (discovery_source IN ('','Instagram','Facebook','Google','PersonalRecommendation','WalkIn','Other')),
  availability_mode     TEXT    NOT NULL DEFAULT '' CHECK (availability_mode IN ('','Weekdays','AnyDay','SpecificDays')),
  preferred_days        TEXT    NOT NULL DEFAULT '',
  preferred_time        TEXT    NULL,
  visit_frequency_weeks INTEGER NULL,
  version               INTEGER NOT NULL DEFAULT 1,
  created_at            TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at            TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  CONSTRAINT uq_patients_code UNIQUE (code),
  CONSTRAINT ck_patients_first_name_not_blank CHECK (trim(first_name) <> ''),
  CONSTRAINT ck_patients_last_name_not_blank  CHECK (trim(last_name) <> ''),
  CONSTRAINT ck_patients_birth_date CHECK (birth_date <= substr(registered_at,1,10)),
  CONSTRAINT ck_patients_visit_frequency CHECK (visit_frequency_weeks IS NULL OR visit_frequency_weeks BETWEEN 1 AND 104)
);
-- Varios pacientes sin documento, pero nunca repite uno informado.
CREATE UNIQUE INDEX uq_patients_document_number ON patients (document_number) WHERE document_number <> '';
CREATE INDEX ix_patients_last_name_first_name_id ON patients (last_name, first_name, id);
CREATE INDEX ix_patients_phone_normalized ON patients (phone_normalized);

-- Código de paciente correlativo (equivalente a patient_code_seq START 84).
CREATE TABLE patient_code_seq (
  id  INTEGER PRIMARY KEY CHECK (id = 1),
  next_value INTEGER NOT NULL
);
INSERT INTO patient_code_seq (id, next_value) VALUES (1, 84);

-- phone_normalized y version se calculan en la capa de aplicación
-- (equivalente a la columna GENERATED STORED y al disparador
-- fn_patient_increment_version del original). En SQLite un BEFORE UPDATE no
-- puede reescribir NEW ni invocar funciones propias, así que la regla vive en
-- el repositorio, que siempre actualiza ambos campos.

-- ---------------------------------------------------------- agenda y series ---
CREATE TABLE recurrence_series (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id        INTEGER NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  service_name      TEXT    NOT NULL,
  professional_name TEXT    NOT NULL,
  frequency         TEXT    NOT NULL DEFAULT 'Weekly' CHECK (frequency IN ('Daily','Weekly','Biweekly','Monthly','Custom')),
  interval_value    INTEGER NOT NULL DEFAULT 1 CHECK (interval_value BETWEEN 1 AND 52),
  start_at          TEXT    NOT NULL,
  end_at            TEXT    NOT NULL,
  duration_minutes  INTEGER NOT NULL DEFAULT 45,
  occurrences       INTEGER NOT NULL CHECK (occurrences BETWEEN 1 AND 100),
  generated_occurrences INTEGER NOT NULL DEFAULT 0,
  blocked_reason    TEXT    NULL,
  created_at        TEXT    NOT NULL,
  CONSTRAINT ck_recurrence_service_not_blank CHECK (trim(service_name) <> ''),
  CONSTRAINT ck_recurrence_professional_not_blank CHECK (trim(professional_name) <> ''),
  CONSTRAINT ck_recurrence_range CHECK (start_at < end_at),
  CONSTRAINT ck_recurrence_duration CHECK (duration_minutes > 0 AND duration_minutes <= 720)
);
CREATE INDEX ix_recurrence_series_patient_start ON recurrence_series (patient_id, start_at);
CREATE INDEX ix_recurrence_series_professional_start ON recurrence_series (lower(trim(professional_name)), start_at);

-- Cursor separado para series continuas (017_ongoing_recurrences.sql). Conserva
-- las series finitas y las excepciones individuales ya existentes.
CREATE TABLE ongoing_recurrences (
  series_id INTEGER PRIMARY KEY REFERENCES recurrence_series(id) ON DELETE CASCADE,
  next_at   TEXT NOT NULL,
  notes     TEXT NOT NULL DEFAULT '',
  stopped_at TEXT NULL
);
CREATE INDEX ix_ongoing_recurrences_due ON ongoing_recurrences (next_at) WHERE stopped_at IS NULL;

CREATE TABLE appointments (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id          INTEGER NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  professional_id     INTEGER NOT NULL DEFAULT 0,
  patient_name        TEXT    NOT NULL DEFAULT '',
  service_name        TEXT    NOT NULL,
  starts_at           TEXT    NOT NULL,
  ends_at             TEXT    NOT NULL,
  status              TEXT    NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending','Confirmed','Waiting','InProgress','Attended','Cancelled','NoShow','Rescheduled')),
  notes               TEXT    NOT NULL DEFAULT '',
  is_recurring        INTEGER NOT NULL DEFAULT 0 CHECK (is_recurring IN (0,1)),
  recurrence_series_id INTEGER NULL REFERENCES recurrence_series(id) ON DELETE RESTRICT,
  professional_name   TEXT    NOT NULL,
  service_price       INTEGER NOT NULL DEFAULT 0 CHECK (service_price >= 0 AND service_price <= 1000000000),
  discount_percent    INTEGER NOT NULL DEFAULT 0 CHECK (discount_percent >= 0 AND discount_percent <= 10000),
  discount_amount     INTEGER NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
  final_price         INTEGER NOT NULL DEFAULT 0 CHECK (final_price >= 0),
  discount_reason     TEXT    NOT NULL DEFAULT '',
  discount_event_id   INTEGER NULL REFERENCES discount_events(id) ON DELETE RESTRICT,
  discount_benefit_id INTEGER NULL REFERENCES patient_discount_benefits(id) ON DELETE RESTRICT,
  version             INTEGER NOT NULL DEFAULT 1,
  created_at          TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at          TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  CONSTRAINT ck_appointments_service_not_blank CHECK (trim(service_name) <> ''),
  CONSTRAINT ck_appointments_professional_not_blank CHECK (trim(professional_name) <> ''),
  CONSTRAINT ck_appointments_range CHECK (starts_at < ends_at),
  CONSTRAINT ck_appointments_recurrence_link CHECK ((is_recurring = 0 AND recurrence_series_id IS NULL) OR (is_recurring = 1 AND recurrence_series_id IS NOT NULL)),
  CONSTRAINT ck_appointments_discount CHECK (discount_amount <= service_price AND final_price <= service_price)
);
CREATE INDEX ix_appointments_starts_at ON appointments (starts_at, id);
CREATE INDEX ix_appointments_patient_starts_at ON appointments (patient_id, starts_at DESC, id DESC);
CREATE INDEX ix_appointments_professional_window ON appointments (lower(trim(professional_name)), starts_at, ends_at) WHERE status <> 'Cancelled';
CREATE INDEX ix_appointments_recurrence_series ON appointments (recurrence_series_id, starts_at) WHERE recurrence_series_id IS NOT NULL;

-- Detección atómica de solape por profesional (sp_appointment_create del original
-- y el disparador equivalente del baseline previo). No se cuentan las canceladas.
CREATE TRIGGER tr_appointments_overlap_insert BEFORE INSERT ON appointments
WHEN NEW.status <> 'Cancelled'
BEGIN
  SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.status <> 'Cancelled'
      AND lower(trim(a.professional_name)) = lower(trim(NEW.professional_name))
      AND a.starts_at < NEW.ends_at AND NEW.starts_at < a.ends_at
  );
END;
CREATE TRIGGER tr_appointments_overlap_update BEFORE UPDATE OF starts_at, ends_at, professional_name, status ON appointments
WHEN NEW.status <> 'Cancelled'
BEGIN
  SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.id <> NEW.id
      AND a.status <> 'Cancelled'
      AND lower(trim(a.professional_name)) = lower(trim(NEW.professional_name))
      AND a.starts_at < NEW.ends_at AND NEW.starts_at < a.ends_at
  );
END;

-- ------------------------------------------------------- historia clínica -----
CREATE TABLE clinical_attentions (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id        INTEGER NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  appointment_id    INTEGER NULL REFERENCES appointments(id) ON DELETE RESTRICT,
  attention_date    TEXT    NOT NULL,
  professional_name TEXT    NOT NULL,
  reason            TEXT    NOT NULL DEFAULT '',
  evaluation        TEXT    NOT NULL DEFAULT '',
  procedure_text    TEXT    NOT NULL DEFAULT '',
  recommendations   TEXT    NOT NULL DEFAULT '',
  created_at        TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  CONSTRAINT ck_clinical_professional_not_blank CHECK (trim(professional_name) <> ''),
  CONSTRAINT ck_clinical_earliest_date CHECK (attention_date >= '2000-01-01T00:00:00')
);
CREATE INDEX ix_clinical_attentions_patient_date ON clinical_attentions (patient_id, attention_date DESC, id DESC);
CREATE INDEX ix_clinical_attentions_appointment ON clinical_attentions (appointment_id) WHERE appointment_id IS NOT NULL;

-- Borradores privados por cuenta; los resultados sólo evitan duplicar un reintento.
CREATE TABLE clinical_drafts (
  owner_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  draft_key  TEXT    NOT NULL,
  id         TEXT    NOT NULL,
  version    INTEGER NOT NULL,
  updated_at TEXT    NOT NULL,
  content    TEXT    NOT NULL,
  PRIMARY KEY (owner_id, draft_key)
);
CREATE INDEX ix_clinical_drafts_updated_at ON clinical_drafts (updated_at);
CREATE TABLE clinical_draft_results (
  owner_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  draft_id   TEXT    NOT NULL,
  attention_id INTEGER NOT NULL REFERENCES clinical_attentions(id),
  PRIMARY KEY (owner_id, draft_id)
);

-- -------------------------------------------------- tratamientos y sesiones ---
CREATE TABLE treatments (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id         INTEGER NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  patient_name       TEXT    NOT NULL DEFAULT '',
  name               TEXT    NOT NULL,
  start_date         TEXT    NOT NULL,
  total_sessions     INTEGER NOT NULL CHECK (total_sessions BETWEEN 1 AND 100),
  completed_sessions INTEGER NOT NULL DEFAULT 0 CHECK (completed_sessions >= 0),
  price              INTEGER NOT NULL DEFAULT 0 CHECK (price BETWEEN 0 AND 1000000000),
  status             TEXT    NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Completed','Abandoned','Paused')),
  professional_name  TEXT    NOT NULL DEFAULT '',
  notes              TEXT    NOT NULL DEFAULT '',
  created_at         TEXT    NOT NULL,
  CONSTRAINT ck_treatments_name_not_blank CHECK (trim(name) <> ''),
  CONSTRAINT ck_treatments_completed CHECK (completed_sessions <= total_sessions)
);
CREATE INDEX ix_treatments_patient_status_created ON treatments (patient_id, status, created_at DESC, id DESC);

CREATE TABLE treatment_sessions (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  treatment_id        INTEGER NOT NULL REFERENCES treatments(id) ON DELETE RESTRICT,
  clinical_attention_id INTEGER NULL REFERENCES clinical_attentions(id) ON DELETE RESTRICT,
  session_date        TEXT    NOT NULL,
  number              INTEGER NOT NULL CHECK (number > 0),
  notes               TEXT    NOT NULL DEFAULT '',
  operation_id        TEXT    NULL,
  CONSTRAINT uq_treatment_sessions_treatment_number UNIQUE (treatment_id, number)
);
CREATE INDEX ix_treatment_sessions_treatment_date ON treatment_sessions (treatment_id, session_date, id);
CREATE INDEX ix_treatment_sessions_attention ON treatment_sessions (clinical_attention_id) WHERE clinical_attention_id IS NOT NULL;
CREATE UNIQUE INDEX ux_treatment_session_operation ON treatment_sessions (operation_id) WHERE operation_id IS NOT NULL;

-- ----------------------------------------------------------- seguimientos -----
CREATE TABLE follow_ups (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id       INTEGER NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  patient_name     TEXT    NOT NULL DEFAULT '',
  type             TEXT    NOT NULL,
  target_date      TEXT    NOT NULL,
  responsible_name TEXT    NOT NULL,
  description      TEXT    NOT NULL DEFAULT '',
  priority         TEXT    NOT NULL DEFAULT 'Medium' CHECK (priority IN ('Low','Medium','High')),
  status           TEXT    NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending','InProgress','Completed','Cancelled','Overdue')),
  CONSTRAINT ck_follow_ups_type_not_blank CHECK (trim(type) <> ''),
  CONSTRAINT ck_follow_ups_responsible_not_blank CHECK (trim(responsible_name) <> '')
);
CREATE INDEX ix_follow_ups_target_status ON follow_ups (target_date, status, id);
CREATE INDEX ix_follow_ups_patient_target ON follow_ups (patient_id, target_date, id);
