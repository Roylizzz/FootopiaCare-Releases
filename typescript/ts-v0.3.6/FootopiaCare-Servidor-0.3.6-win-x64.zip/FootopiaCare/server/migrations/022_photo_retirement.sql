-- Retiro lógico: conservar originales y vínculos clínicos, sin inventar una política de purga.
ALTER TABLE patient_photos ADD COLUMN retired_at TEXT NULL;
ALTER TABLE patient_photos ADD COLUMN retirement_reason TEXT NOT NULL DEFAULT '';
ALTER TABLE patient_photos ADD COLUMN retired_by TEXT NOT NULL DEFAULT '';
