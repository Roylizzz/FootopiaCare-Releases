-- Identidades y credenciales de réplica. Los secretos de vinculación y acceso se almacenan como huellas.
CREATE TABLE sync_installation (
  id INTEGER PRIMARY KEY CHECK (id=1),
  installation_id TEXT NOT NULL UNIQUE
);

CREATE TABLE sync_devices (
  device_id TEXT PRIMARY KEY,
  device_name TEXT NOT NULL,
  credential_hash TEXT NOT NULL UNIQUE,
  owner_id INTEGER NOT NULL REFERENCES users(id),
  linked_at TEXT NOT NULL,
  revoked_at TEXT
);

CREATE TABLE sync_pairing_codes (
  code_hash TEXT PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES users(id),
  expires_at INTEGER NOT NULL,
  device_id TEXT REFERENCES sync_devices(device_id),
  credential_hash TEXT
);

CREATE INDEX ix_sync_pairing_expiry ON sync_pairing_codes(expires_at);
