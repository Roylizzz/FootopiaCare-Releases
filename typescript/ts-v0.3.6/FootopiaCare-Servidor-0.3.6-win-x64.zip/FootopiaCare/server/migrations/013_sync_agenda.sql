-- Fase 3 de sincronización: agenda. Se reconstruye sync_ids para ampliar el CHECK
-- conservando todas las identidades ya acordadas con los teléfonos.
CREATE TABLE sync_ids_v3 (
 entity    TEXT    NOT NULL CHECK (entity IN ('patients','discount_events','form_templates','consent_template_versions',
                                              'schedule_exceptions','products','settings',
                                              'recurrence_series','ongoing_recurrences','patient_discount_benefits',
                                              'appointments','wait_list_entries')),
 local_id  INTEGER NOT NULL,
 global_id TEXT    NOT NULL UNIQUE,
 PRIMARY KEY (entity, local_id)
);
INSERT INTO sync_ids_v3 (entity, local_id, global_id) SELECT entity, local_id, global_id FROM sync_ids;
DROP TABLE sync_ids;
ALTER TABLE sync_ids_v3 RENAME TO sync_ids;
