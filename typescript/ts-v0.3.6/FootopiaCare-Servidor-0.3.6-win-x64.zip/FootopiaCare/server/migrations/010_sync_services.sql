CREATE TABLE sync_service_ids (
 service_id INTEGER PRIMARY KEY REFERENCES services(id),
 global_id TEXT NOT NULL UNIQUE
);
