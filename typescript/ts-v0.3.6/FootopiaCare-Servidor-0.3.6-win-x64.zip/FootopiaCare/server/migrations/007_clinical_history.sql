-- Historia por paciente/profesional y fecha, sin reescribir migraciones publicadas.
CREATE INDEX ix_history_patient_professional_date ON clinical_attentions(patient_id,professional_name,attention_date DESC,id DESC);
