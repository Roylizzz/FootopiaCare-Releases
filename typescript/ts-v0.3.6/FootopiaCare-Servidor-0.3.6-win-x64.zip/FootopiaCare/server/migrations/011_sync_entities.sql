-- Identidad global de los registros sincronizados con Android (una fila por entidad y registro local).
CREATE TABLE sync_ids (
 entity    TEXT    NOT NULL CHECK (entity IN ('patients')),
 local_id  INTEGER NOT NULL,
 global_id TEXT    NOT NULL UNIQUE,
 PRIMARY KEY (entity, local_id)
);
