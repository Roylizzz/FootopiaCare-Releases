-- Las firmas nuevas usan el texto del formulario original sin gestionar ni aprobar
-- versiones (078_consent_without_versions del original). Los registros históricos
-- se conservan tal cual. SQLite no permite cambiar un CHECK: se reconstruye la
-- tabla copiando las filas y se reponen índices y disparadores de inmutabilidad.
DROP TRIGGER IF EXISTS tr_consent_record_immutable;
DROP TRIGGER IF EXISTS tr_consent_content_immutable;

CREATE TABLE consent_contents_v2 (
  consent_id            INTEGER PRIMARY KEY REFERENCES consents(id) ON DELETE RESTRICT,
  template_version_id   INTEGER NULL REFERENCES consent_template_versions(id) ON DELETE RESTRICT,
  accepted_text         TEXT    NOT NULL DEFAULT '',
  content_hash          TEXT    NOT NULL,
  patient_name          TEXT    NOT NULL,
  recorded_by           TEXT    NOT NULL,
  signature_hash        TEXT    NOT NULL DEFAULT '',
  signed_document_path  TEXT    NOT NULL DEFAULT '',
  CONSTRAINT ck_consent_content_source CHECK (accepted_text <> '' OR signed_document_path <> ''),
  CONSTRAINT ck_consent_content_hash CHECK (length(content_hash) = 64)
);
INSERT INTO consent_contents_v2 (consent_id, template_version_id, accepted_text, content_hash, patient_name, recorded_by, signature_hash, signed_document_path)
SELECT consent_id, template_version_id, accepted_text, content_hash, patient_name, recorded_by, signature_hash, signed_document_path FROM consent_contents;
DROP TABLE consent_contents;
ALTER TABLE consent_contents_v2 RENAME TO consent_contents;
CREATE UNIQUE INDEX uq_consent_signed_document ON consent_contents (signed_document_path) WHERE signed_document_path <> '';

CREATE TRIGGER tr_consent_content_immutable BEFORE UPDATE ON consent_contents
BEGIN
  SELECT RAISE(ABORT,'El contenido de un consentimiento registrado no se puede sustituir.');
END;
CREATE TRIGGER tr_consent_record_immutable BEFORE UPDATE ON consents
WHEN EXISTS (SELECT 1 FROM consent_contents WHERE consent_id = OLD.id)
BEGIN
  SELECT RAISE(ABORT,'Los datos de un consentimiento vinculado no se pueden sustituir.');
END;
