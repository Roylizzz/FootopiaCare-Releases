-- Fase 5 de sincronización: soportes de pago. Se reconstruye sync_ids para ampliar el CHECK
-- conservando todas las identidades ya acordadas con los teléfonos.
CREATE TABLE sync_ids_v7 (
 entity    TEXT    NOT NULL CHECK (entity IN ('patients','discount_events','form_templates','consent_template_versions',
                                              'schedule_exceptions','products','settings',
                                              'recurrence_series','ongoing_recurrences','patient_discount_benefits',
                                              'appointments','wait_list_entries',
                                              'clinical_attentions','treatments','treatment_sessions','follow_ups',
                                              'form_responses','patient_notes','tasks',
                                              'sales','sale_lines','payments','inventory_movements',
                                              'consents','consent_contents','patient_documents','patient_photos','product_photos','sale_payment_supports')),
 local_id  INTEGER NOT NULL,
 global_id TEXT    NOT NULL UNIQUE,
 PRIMARY KEY (entity, local_id)
);
INSERT INTO sync_ids_v7 (entity, local_id, global_id) SELECT entity, local_id, global_id FROM sync_ids;
DROP TABLE sync_ids;
ALTER TABLE sync_ids_v7 RENAME TO sync_ids;

