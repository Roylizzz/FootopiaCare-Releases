-- Fase 5 de sincronización: archivos privados. Se reconstruye sync_ids para ampliar el CHECK
-- conservando todas las identidades ya acordadas con los teléfonos.
CREATE TABLE sync_ids_v6 (
 entity    TEXT    NOT NULL CHECK (entity IN ('patients','discount_events','form_templates','consent_template_versions',
                                              'schedule_exceptions','products','settings',
                                              'recurrence_series','ongoing_recurrences','patient_discount_benefits',
                                              'appointments','wait_list_entries',
                                              'clinical_attentions','treatments','treatment_sessions','follow_ups',
                                              'form_responses','patient_notes','tasks',
                                              'sales','sale_lines','payments','inventory_movements',
                                              'consents','consent_contents','patient_documents','patient_photos','product_photos')),
 local_id  INTEGER NOT NULL,
 global_id TEXT    NOT NULL UNIQUE,
 PRIMARY KEY (entity, local_id)
);
INSERT INTO sync_ids_v6 (entity, local_id, global_id) SELECT entity, local_id, global_id FROM sync_ids;
DROP TABLE sync_ids;
ALTER TABLE sync_ids_v6 RENAME TO sync_ids;

-- Huella SHA-256 de cada archivo privado sincronizable (y de su miniatura). Las rutas privadas nunca se
-- sobrescriben, así que la huella de una ruta es estable y se calcula una sola vez.
CREATE TABLE sync_file_hashes (
 path         TEXT    PRIMARY KEY,
 sha256       TEXT    NOT NULL,
 thumb_sha256 TEXT    NOT NULL DEFAULT '',
 size         INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX ix_sync_file_hashes_sha256 ON sync_file_hashes (sha256) WHERE sha256 <> '';
CREATE INDEX ix_sync_file_hashes_thumb ON sync_file_hashes (thumb_sha256) WHERE thumb_sha256 <> '';
