-- Fase 2 de sincronización: datos maestros. SQLite no permite ampliar un CHECK,
-- así que se reconstruye sync_ids conservando todas las identidades ya acordadas.
CREATE TABLE sync_ids_v2 (
 entity    TEXT    NOT NULL CHECK (entity IN ('patients','discount_events','form_templates','consent_template_versions',
                                              'schedule_exceptions','products','settings')),
 local_id  INTEGER NOT NULL,
 global_id TEXT    NOT NULL UNIQUE,
 PRIMARY KEY (entity, local_id)
);
INSERT INTO sync_ids_v2 (entity, local_id, global_id) SELECT entity, local_id, global_id FROM sync_ids;
DROP TABLE sync_ids;
ALTER TABLE sync_ids_v2 RENAME TO sync_ids;
