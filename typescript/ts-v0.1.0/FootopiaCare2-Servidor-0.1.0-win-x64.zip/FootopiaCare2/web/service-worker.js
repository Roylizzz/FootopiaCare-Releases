/* Offline assets only. NEVER cache /api, clinical documents, photos, responses or credentials. */
const CACHE = 'footopia-shell-v1';
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(['/manifest.webmanifest','/icon-192.png','/icon-512.png'])));
  self.skipWaiting();
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', event => {
  const request=event.request;
  if(request.method !== 'GET') return;
  const url=new URL(request.url);
  if(url.origin !== self.location.origin || url.pathname.startsWith('/api/') || !/^\/(assets\/|icon-|manifest\.webmanifest|favicon)/.test(url.pathname)) return;
  event.respondWith(fetch(request).then(response => {
    if(response.ok && response.type === 'basic') {
      const copy=response.clone();
      event.waitUntil(caches.open(CACHE).then(cache => cache.put(request,copy)));
    }
    return response;
  }).catch(() => caches.match(request)));
});
