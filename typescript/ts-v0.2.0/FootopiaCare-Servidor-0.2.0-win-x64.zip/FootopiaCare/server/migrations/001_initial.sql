-- FootopiaCare 2.0 / baseline SQLite. Application sets PRAGMA foreign_keys=ON per connection.
-- Dates for appointments are clinic wall-clock strings in America/Bogota; created_at is UTC ISO.
CREATE TABLE users (
  id TEXT PRIMARY KEY, username TEXT NOT NULL COLLATE NOCASE UNIQUE,
  display_name TEXT NOT NULL, password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('Admin','Reception','Clinical','Full')),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE user_permissions (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  permission TEXT NOT NULL CHECK(permission IN ('reception','clinical','commerce','export','photos.delete','administration')),
  granted INTEGER NOT NULL CHECK(granted IN (0,1)),
  PRIMARY KEY(user_id,permission)
);
CREATE TABLE sessions (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE, expires_at TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE business_hours (
  id TEXT PRIMARY KEY, weekday INTEGER NOT NULL CHECK(weekday BETWEEN 0 AND 6),
  start_time TEXT NOT NULL, end_time TEXT NOT NULL, CHECK(start_time < end_time),
  UNIQUE(weekday,start_time,end_time)
);
CREATE TABLE schedule_exceptions (
  id TEXT PRIMARY KEY, day TEXT NOT NULL, closed INTEGER NOT NULL DEFAULT 0 CHECK(closed IN (0,1)),
  start_time TEXT, end_time TEXT, note TEXT NOT NULL DEFAULT '',
  CHECK((closed=1 AND start_time IS NULL AND end_time IS NULL) OR (closed=0 AND start_time < end_time))
);
CREATE INDEX idx_schedule_exceptions_day ON schedule_exceptions(day);
CREATE TABLE patients (
  id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, first_name TEXT NOT NULL, last_name TEXT NOT NULL,
  birth_date TEXT NOT NULL, gender TEXT NOT NULL CHECK(gender IN ('Female','Male','Unspecified')),
  document_number TEXT, phone TEXT, email TEXT, address TEXT, allergies TEXT,
  personal_products TEXT, clinical_notes TEXT, preferred_days_json TEXT NOT NULL DEFAULT '[]',
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1 CHECK(version>0), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX idx_patient_document ON patients(document_number) WHERE document_number IS NOT NULL AND document_number <> '';
CREATE INDEX idx_patient_names ON patients(last_name,first_name);
CREATE INDEX idx_patient_phone ON patients(phone);
CREATE TABLE patient_notes (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  note TEXT NOT NULL, created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE services (
  id TEXT PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE, duration_minutes INTEGER NOT NULL CHECK(duration_minutes BETWEEN 5 AND 480),
  price_minor INTEGER NOT NULL CHECK(price_minor>=0), active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
);
CREATE TABLE appointment_series (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  service_id TEXT NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
  professional_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  anchor_date TEXT NOT NULL, time_of_day TEXT NOT NULL, duration_minutes INTEGER NOT NULL CHECK(duration_minutes BETWEEN 5 AND 480),
  weekdays_json TEXT NOT NULL, interval_weeks INTEGER NOT NULL CHECK(interval_weeks BETWEEN 1 AND 12),
  mode TEXT NOT NULL CHECK(mode IN ('finite','ongoing')), target_count INTEGER CHECK(target_count BETWEEN 1 AND 100),
  generated_count INTEGER NOT NULL DEFAULT 0 CHECK(generated_count>=0),
  next_date TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'Active' CHECK(state IN ('Active','Stopped')),
  blocked_reason TEXT, stopped_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK((mode='finite' AND target_count IS NOT NULL) OR (mode='ongoing' AND target_count IS NULL))
);
CREATE INDEX idx_series_due ON appointment_series(state,next_date);
CREATE TABLE appointments (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  service_id TEXT NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
  professional_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  series_id TEXT REFERENCES appointment_series(id) ON DELETE RESTRICT,
  nominal_date TEXT NOT NULL, start_local TEXT NOT NULL, end_local TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Confirmed','Waiting','InProgress','Attended','Cancelled','NoShow')),
  manual_override INTEGER NOT NULL DEFAULT 0 CHECK(manual_override IN (0,1)),
  price_minor INTEGER NOT NULL CHECK(price_minor>=0), discount_minor INTEGER NOT NULL DEFAULT 0 CHECK(discount_minor>=0),
  final_minor INTEGER NOT NULL CHECK(final_minor>=0), discount_reason TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '', version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK(start_local < end_local), CHECK(price_minor-discount_minor=final_minor)
);
CREATE UNIQUE INDEX idx_series_nominal ON appointments(series_id,nominal_date) WHERE series_id IS NOT NULL;
CREATE INDEX idx_appointments_range ON appointments(start_local,end_local);
CREATE INDEX idx_appointments_professional ON appointments(professional_id,start_local,end_local);
CREATE INDEX idx_appointments_patient ON appointments(patient_id,start_local);
CREATE TRIGGER prevent_overlap_insert BEFORE INSERT ON appointments WHEN NEW.status NOT IN ('Cancelled','NoShow') BEGIN
  SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS(
    SELECT 1 FROM appointments a WHERE a.professional_id=NEW.professional_id
      AND a.status NOT IN ('Cancelled','NoShow') AND a.start_local < NEW.end_local AND a.end_local > NEW.start_local
  );
END;
CREATE TRIGGER prevent_overlap_update BEFORE UPDATE OF start_local,end_local,professional_id,status ON appointments WHEN NEW.status NOT IN ('Cancelled','NoShow') BEGIN
  SELECT RAISE(ABORT,'APPOINTMENT_CONFLICT') WHERE EXISTS(
    SELECT 1 FROM appointments a WHERE a.id<>NEW.id AND a.professional_id=NEW.professional_id
      AND a.status NOT IN ('Cancelled','NoShow') AND a.start_local < NEW.end_local AND a.end_local > NEW.start_local
  );
END;
CREATE TABLE clinical_drafts (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  body_json TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id,patient_id)
);
CREATE TABLE clinical_attentions (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  appointment_id TEXT REFERENCES appointments(id) ON DELETE RESTRICT,
  professional_id TEXT NOT NULL REFERENCES users(id), reason TEXT NOT NULL,
  evaluation TEXT NOT NULL DEFAULT '', procedure_text TEXT NOT NULL DEFAULT '', recommendations TEXT NOT NULL DEFAULT '',
  follow_up_date TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_attentions_patient ON clinical_attentions(patient_id,created_at);
CREATE TABLE treatments (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  name TEXT NOT NULL, total_sessions INTEGER NOT NULL CHECK(total_sessions>0),
  price_minor INTEGER NOT NULL DEFAULT 0 CHECK(price_minor>=0), status TEXT NOT NULL DEFAULT 'Active' CHECK(status IN ('Active','Completed','Cancelled')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE treatment_sessions (
  id TEXT PRIMARY KEY, treatment_id TEXT NOT NULL REFERENCES treatments(id) ON DELETE RESTRICT,
  attention_id TEXT REFERENCES clinical_attentions(id) ON DELETE RESTRICT,
  session_number INTEGER NOT NULL CHECK(session_number>0), completed_at TEXT NOT NULL, operation_key TEXT NOT NULL UNIQUE,
  UNIQUE(treatment_id,session_number)
);
CREATE TABLE follow_ups (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  source_attention_id TEXT REFERENCES clinical_attentions(id) ON DELETE RESTRICT,
  due_date TEXT NOT NULL, title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Completed','Cancelled')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_followups_due ON follow_ups(status,due_date);
CREATE TABLE tasks (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, patient_id TEXT REFERENCES patients(id) ON DELETE RESTRICT,
  responsible_id TEXT REFERENCES users(id) ON DELETE RESTRICT, due_date TEXT,
  completed INTEGER NOT NULL DEFAULT 0 CHECK(completed IN (0,1)), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE wait_list (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  service_id TEXT REFERENCES services(id) ON DELETE RESTRICT, professional_id TEXT REFERENCES users(id) ON DELETE RESTRICT,
  from_date TEXT NOT NULL, to_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Reserved','Cancelled')),
  appointment_id TEXT REFERENCES appointments(id) ON DELETE RESTRICT, CHECK(from_date<=to_date)
);
CREATE TABLE patient_photos (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  attention_id TEXT REFERENCES clinical_attentions(id) ON DELETE RESTRICT,
  relative_path TEXT NOT NULL UNIQUE, mime TEXT NOT NULL, file_size INTEGER NOT NULL CHECK(file_size>0), sha256 TEXT NOT NULL,
  label TEXT NOT NULL DEFAULT '', taken_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_photos_patient ON patient_photos(patient_id,taken_at);
CREATE TABLE patient_documents (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  relative_path TEXT NOT NULL UNIQUE, mime TEXT NOT NULL, sha256 TEXT NOT NULL,
  file_name TEXT NOT NULL, kind TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE consents (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  accepted_text TEXT NOT NULL, content_sha256 TEXT NOT NULL, signature_path TEXT NOT NULL UNIQUE,
  signature_sha256 TEXT NOT NULL, recorded_by TEXT NOT NULL REFERENCES users(id),
  notes TEXT NOT NULL DEFAULT '', signed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_consents_patient ON consents(patient_id,signed_at);
CREATE TABLE form_templates (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, schema_json TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
);
CREATE TABLE form_responses (
  id TEXT PRIMARY KEY, template_id TEXT NOT NULL REFERENCES form_templates(id) ON DELETE RESTRICT,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  answers_json TEXT NOT NULL, submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE products (
  id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  price_minor INTEGER NOT NULL CHECK(price_minor>=0), stock INTEGER NOT NULL CHECK(stock>=0),
  minimum_stock INTEGER NOT NULL DEFAULT 0 CHECK(minimum_stock>=0), active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
);
CREATE TABLE sales (
  id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, patient_id TEXT REFERENCES patients(id) ON DELETE RESTRICT,
  total_minor INTEGER NOT NULL CHECK(total_minor>=0), status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Paid','Cancelled')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE sale_lines (
  id TEXT PRIMARY KEY, sale_id TEXT NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  product_name TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity>0),
  unit_price_minor INTEGER NOT NULL CHECK(unit_price_minor>=0), total_minor INTEGER NOT NULL CHECK(total_minor>=0),
  CHECK(quantity*unit_price_minor=total_minor)
);
CREATE INDEX idx_sale_lines_sale ON sale_lines(sale_id);
CREATE TABLE inventory_movements (
  id TEXT PRIMARY KEY, product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  delta INTEGER NOT NULL CHECK(delta<>0), reason TEXT NOT NULL,
  sale_id TEXT REFERENCES sales(id) ON DELETE RESTRICT, actor_id TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE payments (
  id TEXT PRIMARY KEY, sale_id TEXT REFERENCES sales(id) ON DELETE RESTRICT,
  appointment_id TEXT REFERENCES appointments(id) ON DELETE RESTRICT,
  patient_id TEXT REFERENCES patients(id) ON DELETE RESTRICT,
  amount_minor INTEGER NOT NULL CHECK(amount_minor>0), method TEXT NOT NULL CHECK(method IN ('Cash','Transfer','Card','Other')),
  status TEXT NOT NULL DEFAULT 'Paid' CHECK(status IN ('Paid','Pending','Cancelled')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK(NOT (sale_id IS NOT NULL AND appointment_id IS NOT NULL))
);
CREATE INDEX idx_payments_sale ON payments(sale_id,status);
CREATE TABLE discount_events (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, percent INTEGER NOT NULL CHECK(percent BETWEEN 1 AND 100),
  starts_at TEXT NOT NULL, ends_at TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  CHECK(starts_at<ends_at)
);
CREATE TABLE patient_discount_benefits (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  percent INTEGER NOT NULL CHECK(percent BETWEEN 1 AND 100), reason TEXT NOT NULL,
  used_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE notifications (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, detail TEXT NOT NULL, source_kind TEXT NOT NULL,
  source_id TEXT, read_at TEXT, resolved_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE email_jobs (
  id TEXT PRIMARY KEY, event_key TEXT NOT NULL UNIQUE, patient_id TEXT REFERENCES patients(id) ON DELETE RESTRICT,
  appointment_id TEXT REFERENCES appointments(id) ON DELETE RESTRICT,
  recipient TEXT NOT NULL, subject TEXT NOT NULL, body_text TEXT NOT NULL,
  due_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Processing','Sent','Failed','Skipped')),
  attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT, sent_at TEXT
);
CREATE INDEX idx_email_due ON email_jobs(status,due_at);
CREATE TABLE backup_runs (
  id TEXT PRIMARY KEY, folder_path TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('Completed','Failed')),
  database_sha256 TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE operation_receipts (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  action TEXT NOT NULL, operation_key TEXT NOT NULL,
  request_hash TEXT NOT NULL, result_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id,action,operation_key)
);
