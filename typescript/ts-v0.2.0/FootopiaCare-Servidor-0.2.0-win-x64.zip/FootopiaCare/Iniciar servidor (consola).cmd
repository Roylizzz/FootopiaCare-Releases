@echo off
rem Inicia solo el servidor en esta ventana (sin monitor), accesible únicamente desde este PC.
setlocal
set NODE_ENV=production
set HOST=127.0.0.1
set PORT=4161
set WEB_DIST_PATH=%~dp0web
set MIGRATIONS_DIR=%~dp0server\migrations
set FOOTOPIA_VERSION=0.2.0
cd /d "%~dp0server"
echo Footopia Care en http://127.0.0.1:4161  (Ctrl+C para detener)
"%~dp0node\node.exe" server.mjs
pause
